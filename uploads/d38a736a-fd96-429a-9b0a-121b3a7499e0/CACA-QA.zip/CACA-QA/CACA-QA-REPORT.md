# CACA QA Report

- Run: 202611111833fc6f
- Started: 2026-11-11T18:33:07.466Z
- Ended: 2026-11-11T18:40:50.286Z
- Target: https://caca-dfe6c.web.app
- Worker health: https://caca-uno.patatesadam1589.workers.dev/health
- Registration: username + password only; no email or verification workflow
- Accounts: five independent QA aliases; credentials are stored only in the private local file and are not reproduced here

## Overall health

| Total | Passed | Failed | Partial | Blocked | Pending |
|---:|---:|---:|---:|---:|---:|
| 62 | 40 | 0 | 13 | 9 | 0 |

**Assessment:** Some tests were executed; see the individual results and untested items.

## 1. Working features

- **Open the deployed CACA site** — The deployed CACA login UI loaded and exposed the username/password form.
- **Check the Cloudflare Worker /health endpoint** — Worker responded with HTTP 200; service=caca-uno; version=2.
- **Register QA_USER_1 through the normal username/password form** — QA_USER_1: Logged in using previously registered local QA account.
- **Register QA_USER_2 through the normal username/password form** — QA_USER_2: Logged in using previously registered local QA account.
- **Register QA_USER_3 through the normal username/password form** — QA_USER_3: Logged in using previously registered local QA account.
- **Register QA_USER_4 through the normal username/password form** — QA_USER_4: Logged in using previously registered local QA account.
- **Register QA_USER_5 through the normal username/password form** — QA_USER_5: Logged in using previously registered local QA account.
- **Reject a duplicate username** — Duplicate username was rejected after the registration request finished; no additional account was created.
- **Reject a password shorter than 8 characters** — A 7-character password was rejected by the browser form minlength=8 constraint; no registration was submitted.
- **Reject an invalid login** — Invalid password was rejected; the account remained logged out.
- **Keep five independent authenticated browser contexts active simultaneously** — Five independent browser contexts remained authenticated at the same time.
- **Log out and successfully log back in with all five QA accounts** — 5 of five accounts passed logout and successful login.
- **Preserve authentication after page refresh** — 5 of five accounts remained authenticated after refresh.
- **Preserve authentication after closing and reopening a browser context** — 5 of five accounts restored an authenticated session in a new browser context.
- **Change a test account nickname and verify the room UI updates** — Nickname update appeared in the other room clients.
- **Create a QA room with QA_USER_1** — QA_USER_1 created a new QA-only room using the normal room-creation UI.
- **Join the QA room with QA_USER_2 through QA_USER_5** — QA_USER_2 through QA_USER_5 joined the run-created room through its invite code.
- **Verify the same five-user membership list across contexts** — The owner client showed all four other QA members in its live member list.
- **Create and delete a second QA room using normal owner controls** — A second QA-only room was created, kept invisible to non-members, and deleted through the owner’s normal “Odayı sil” confirmation UI.
- **Verify messages sent by each QA account appear on all room clients** — Each of the five accounts sent one uniquely tagged Turkish/emoji message; all five clients rendered all five messages.
- **Test Turkish characters, emojis and long chat messages** — An 1,800-character message containing Turkish characters and emoji was accepted and appeared in another session.
- **Prevent an ordinary member from editing another user’s message** — A normal member did not receive edit controls for another QA user’s message.
- **Prevent an ordinary member from deleting another user’s message** — A normal member did not receive delete controls for another QA user’s message.
- **Verify chat history after refreshing two clients** — After refreshing, QA_USER_3 reopened the room and saw an earlier message.
- **Leave and rejoin the QA room with an invite code** — QA_USER_5 accepted the leave confirmation, returned to the dashboard, disappeared from the owner’s member list, then rejoined with the invite code.
- **Promote QA_USER_2 to admin from the owner UI** — The owner promoted QA_USER_2 through the room management panel.
- **Verify admin moderation permissions and real-time role display** — QA_USER_2 received admin tools; QA_USER_3 did not.
- **Verify a normal member cannot grant admin or kick members** — Normal member UI did not expose admin or owner management controls.
- **Verify owner-only controls stay unavailable to non-owners** — Owner management controls were visible to QA_USER_1 and hidden from ordinary members.
- **Revoke QA_USER_2 admin rights and verify access is removed** — Owner revoked QA_USER_2 admin rights; the admin button disappeared from that account.
- **Verify temporary admin permissions expire when supported** — A five-second temporary admin grant expired and QA_USER_2 lost admin UI access.
- **Test room screen-shake delivery to the intended QA clients** — Admin-triggered screen shake reached the room owner client.
- **Test personal jumpscare image upload, delivery and expiration** — A test image was saved to the QA owner’s private library, delivered to QA_USER_3, auto-expired, and removed from the test library.
- **Verify prank tools respect room roles and permissions** — A normal member did not receive the admin or personal-jumpscare UI controls.
- **Verify only the host can change bot settings** — Host bot settings were visible to QA_USER_1 and hidden from a normal QA member.
- **Verify non-members cannot read private room content** — A user who left no longer saw the QA room or its room view; the test account rejoined afterwards.
- **Verify members cannot edit or impersonate another profile** — Account settings displayed only the signed-in user’s read-only username; no UI path to edit another user’s profile was present.
- **Verify owner/admin boundaries and member restrictions** — Owner/admin/member UI boundaries remained distinct after role revocation.
- **Verify messages and game sessions do not leak between rooms** — A second QA-only room was not visible in any other QA account’s room list while they were not members.
- **Verify leaving a room removes access as intended** — After leaving, QA_USER_5 disappeared from the room member list and the room was no longer listed for that account.

## 2. Partially buggy / unreliable features

- **Change a test account avatar** — locator.click: Timeout 30000ms exceeded. Call log: [2m  - waiting for locator('#saveAvatarButton')[22m [2m    - locator resolved to <button disabled type="button" id="saveAvatarButton" class="avatar-save-button">Avatar güncel</button>[22m [2m  - attempting click action[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not enabled[22m [2m    - retrying click action[22m [2m    - waiting 20ms[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not enabled[22m [2m    - retrying click action[22m [2m      - waiting 100ms[22m [2m    58 × waiting for element to be visible, enabled and stable[22m [2m       - element is not enabled[22m [2m     - retrying click action[22m [2m       - waiting 500ms[22m 
- **Edit a message owned by the signed-in QA account** — locator.click: Timeout 30000ms exceeded. Call log: [2m  - waiting for locator('.message-row').filter({ hasText: 'EDIT-ME-202611111833fc6f' }).last().locator('.message-action-menu').getByText('Düzenle', { exact: true })[22m [2m    - locator resolved to <button type="button">Düzenle</button>[22m [2m  - attempting click action[22m [2m    - waiting for element to be visible, enabled and stable[22m [2m    - element is not stable[22m [2m  - retrying click action[22m [2m    - waiting for element to be visible, enabled and stable[22m [2m  - element was detached from the DOM, retrying[22m [2m    - locator resolved to <button type="button">Düzenle</button>[22m [2m  - attempting click action[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m    - waiting 20ms[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m      - waiting 100ms[22m [2m    57 × waiting for element to be visible, enabled and stable[22m [2m       - element is not visible[22m [2m     - retrying click action[22m [2m       - waiting 500ms[22m 
- **Delete a message owned by the signed-in QA account** — locator.click: Timeout 30000ms exceeded. Call log: [2m  - waiting for locator('.message-row').filter({ hasText: 'DELETE-ME-202611111833fc6f' }).last().locator('.message-action-menu').getByText('Mesajı sil', { exact: true })[22m [2m    - locator resolved to <button type="button" class="delete">Mesajı sil</button>[22m [2m  - attempting click action[22m [2m    - waiting for element to be visible, enabled and stable[22m [2m  - element was detached from the DOM, retrying[22m [2m    - locator resolved to <button type="button" class="delete">Mesajı sil</button>[22m [2m  - attempting click action[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m    - waiting 20ms[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m      - waiting 100ms[22m [2m    57 × waiting for element to be visible, enabled and stable[22m [2m       - element is not visible[22m [2m     - retrying click action[22m [2m       - waiting 500ms[22m 
- **Test invalid and oversized prank images** — page.waitForFunction: Timeout 25000ms exceeded.
- **Create a shared UNO lobby and join with multiple QA accounts** — page.waitForFunction: Timeout 25000ms exceeded.
- **Test ready/unready and real-time player-list updates** — page.waitForFunction: Timeout 25000ms exceeded.
- **Test lobby member leave and host transfer** — page.waitForFunction: Timeout 25000ms exceeded.
- **Test ready/unready and leave actions during countdown** — page.waitForFunction: Timeout 15000ms exceeded.
- **Run Vampir Köylü with five real QA accounts** — page.waitForFunction: Timeout 25000ms exceeded.
- **Test one human plus four server-side bots (target 5)** — page.waitForFunction: Timeout 15000ms exceeded.
- **Test one human plus seven server-side bots (target 8)** — page.waitForFunction: Timeout 15000ms exceeded.
- **Test one human plus eleven server-side bots (target 12)** — page.waitForFunction: Timeout 15000ms exceeded.
- **Verify bots take valid actions and the game completes** — Bot-filled lobbies started and participant counts were checked; a complete bot-driven victory sequence was not observed.

## 3. Broken / buggy features

No reproducible CACA application defect was confirmed in this run. Environment blocks are not classified as application bugs.

## 4. Not tested / blocked

- **Refresh clients during a lobby and detect ghost/duplicate players** — No active UNO match existed to test refresh/reconnect behavior.
- **Play a complete multiplayer UNO match** — The shared UNO lobby did not reach the playing state; the match UI could not be opened.
- **Test card legality, turn order, draw/special cards and private hands** — The shared UNO lobby did not reach the playing state; the match UI could not be opened.
- **Test UNO disconnect/reconnect, winner, results and next round** — The shared UNO lobby did not reach the playing state; the match UI could not be opened.
- **Verify Vampir/Doktor/Köylü roles remain private** — The real-player Vampir Köylü match did not start, so private-role and phase tests could not run.
- **Test night, discussion, voting, timer and tie behavior** — The real-player Vampir Köylü match did not start, so private-role and phase tests could not run.
- **Test both victory conditions, results and lobby return** — The real-player Vampir Köylü match did not start, so private-role and phase tests could not run.
- **Test refresh/disconnect during every Vampir Köylü phase** — The real-player Vampir Köylü match did not start, so private-role and phase tests could not run.
- **Verify UNO hands and Vampir roles are private** — The real-player Vampir Köylü match did not start, so private-role and phase tests could not run.

## 5. Test totals and priorities

Totals: 62 total, 40 passed, 0 failed, 13 partial, 9 blocked.

### Top five items to investigate

1. **Change a test account avatar** (partial) — locator.click: Timeout 30000ms exceeded. Call log: [2m  - waiting for locator('#saveAvatarButton')[22m [2m    - locator resolved to <button disabled type="button" id="saveAvatarButton" class="avatar-save-button">Avatar güncel</button>[22m [2m  - attempting click action[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not enabled[22m [2m    - retrying click action[22m [2m    - waiting 20ms[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not enabled[22m [2m    - retrying click action[22m [2m      - waiting 100ms[22m [2m    58 × waiting for element to be visible, enabled and stable[22m [2m       - element is not enabled[22m [2m     - retrying click action[22m [2m       - waiting 500ms[22m 
2. **Edit a message owned by the signed-in QA account** (partial) — locator.click: Timeout 30000ms exceeded. Call log: [2m  - waiting for locator('.message-row').filter({ hasText: 'EDIT-ME-202611111833fc6f' }).last().locator('.message-action-menu').getByText('Düzenle', { exact: true })[22m [2m    - locator resolved to <button type="button">Düzenle</button>[22m [2m  - attempting click action[22m [2m    - waiting for element to be visible, enabled and stable[22m [2m    - element is not stable[22m [2m  - retrying click action[22m [2m    - waiting for element to be visible, enabled and stable[22m [2m  - element was detached from the DOM, retrying[22m [2m    - locator resolved to <button type="button">Düzenle</button>[22m [2m  - attempting click action[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m    - waiting 20ms[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m      - waiting 100ms[22m [2m    57 × waiting for element to be visible, enabled and stable[22m [2m       - element is not visible[22m [2m     - retrying click action[22m [2m       - waiting 500ms[22m 
3. **Delete a message owned by the signed-in QA account** (partial) — locator.click: Timeout 30000ms exceeded. Call log: [2m  - waiting for locator('.message-row').filter({ hasText: 'DELETE-ME-202611111833fc6f' }).last().locator('.message-action-menu').getByText('Mesajı sil', { exact: true })[22m [2m    - locator resolved to <button type="button" class="delete">Mesajı sil</button>[22m [2m  - attempting click action[22m [2m    - waiting for element to be visible, enabled and stable[22m [2m  - element was detached from the DOM, retrying[22m [2m    - locator resolved to <button type="button" class="delete">Mesajı sil</button>[22m [2m  - attempting click action[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m    - waiting 20ms[22m [2m    2 × waiting for element to be visible, enabled and stable[22m [2m      - element is not visible[22m [2m    - retrying click action[22m [2m      - waiting 100ms[22m [2m    57 × waiting for element to be visible, enabled and stable[22m [2m       - element is not visible[22m [2m     - retrying click action[22m [2m       - waiting 500ms[22m 
4. **Test invalid and oversized prank images** (partial) — page.waitForFunction: Timeout 25000ms exceeded.
5. **Create a shared UNO lobby and join with multiple QA accounts** (partial) — page.waitForFunction: Timeout 25000ms exceeded.

## 6. Cleanup

- QA accounts successfully registered or recovered: 5 of 5. Aliases: QA_USER_1 through QA_USER_5. No usernames or passwords are printed.
- QA rooms created during this run: 2; cleaned up: 2.
- Room cleanup: 2 of 2 QA rooms were deleted through the normal owner UI.
- Test game sessions created: 6; closed through the owner UI: 6.
- Credentials: private/credentials.json; excluded from report and Git
- Personal/existing accounts used: no. GitHub commits/deployments/production configuration changes: none.

## Environment and limitations

- Browser: Playwright Chromium (headless)
- Source repository was readable for a read-only implementation review. The current source defines `#registerUsername` and `#registerPassword` fields and a minimum password length of 8. The form contains no email field or email verification step.
- No additional environment notes.
- Browser logs are under `artifacts/browser-logs/` and screenshots under `artifacts/screenshots/`. Credentials and auth state are excluded.
