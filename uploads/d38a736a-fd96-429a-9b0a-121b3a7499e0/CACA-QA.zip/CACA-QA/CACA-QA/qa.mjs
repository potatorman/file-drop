#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { chromium, request } from 'playwright';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PRIVATE = path.join(ROOT, 'private');
const AUTH_STATE = path.join(PRIVATE, 'auth-state');
const ARTIFACTS = path.join(ROOT, 'artifacts');
const LOG_DIR = path.join(ARTIFACTS, 'browser-logs');
const SCREENSHOT_DIR = path.join(ARTIFACTS, 'screenshots');
const CREDENTIALS_FILE = path.join(PRIVATE, 'credentials.json');
const RESULTS_FILE = path.join(ROOT, 'results.json');
const REPORT_FILE = path.join(ROOT, 'CACA-QA-REPORT.md');

const BASE_URL = process.env.CACA_BASE_URL || 'https://caca-dfe6c.web.app';
const WORKER_URL = process.env.CACA_WORKER_URL || 'https://caca-uno.patatesadam1589.workers.dev';
const HEALTH_URL = `${WORKER_URL.replace(/\/$/, '')}/health`;
const HEADFUL = process.env.HEADFUL === '1';
const TIMEOUT = Number(process.env.CACA_QA_TIMEOUT_MS || 25000);
const RUN_ID = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 12) + randomBytes(2).toString('hex');

const PLAN = [
  ['site.home', 'Open the deployed CACA site'],
  ['worker.health', 'Check the Cloudflare Worker /health endpoint'],
  ['accounts.register.1', 'Log in to or register QA_USER_1 using username and password'],
  ['accounts.register.2', 'Log in to or register QA_USER_2 using username and password'],
  ['accounts.register.3', 'Log in to or register QA_USER_3 using username and password'],
  ['accounts.register.4', 'Log in to or register QA_USER_4 using username and password'],
  ['accounts.register.5', 'Log in to or register QA_USER_5 using username and password'],
  ['accounts.duplicate', 'Reject a duplicate username'],
  ['accounts.short-password', 'Reject a password shorter than 8 characters'],
  ['accounts.invalid-login', 'Reject an invalid login'],
  ['accounts.concurrent', 'Keep five independent authenticated browser contexts active simultaneously'],
  ['accounts.logout-login', 'Log out and successfully log back in with all five QA accounts'],
  ['accounts.refresh', 'Preserve authentication after page refresh'],
  ['accounts.reopen', 'Preserve authentication after closing and reopening a browser context'],
  ['profiles.nickname', 'Change a test account nickname and verify the room UI updates'],
  ['profiles.avatar', 'Change a test account avatar'],
  ['rooms.create', 'Create a QA room with QA_USER_1'],
  ['rooms.join', 'Join the QA room with QA_USER_2 through QA_USER_5'],
  ['rooms.members', 'Verify the same five-user membership list across contexts'],
  ['rooms.second-delete', 'Create and delete a second QA room using normal owner controls'],
  ['chat.realtime', 'Verify messages sent by each QA account appear on all room clients'],
  ['chat.turkish-emoji-long', 'Test Turkish characters, emojis and long chat messages'],
  ['chat.edit-own', 'Edit a message owned by the signed-in QA account'],
  ['chat.delete-own', 'Delete a message owned by the signed-in QA account'],
  ['chat.prevent-edit-other', 'Prevent an ordinary member from editing another user’s message'],
  ['chat.prevent-delete-other', 'Prevent an ordinary member from deleting another user’s message'],
  ['chat.history-refresh', 'Verify chat history after refreshing two clients'],
  ['rooms.leave-rejoin', 'Leave and rejoin the QA room with an invite code'],
  ['roles.promote-admin', 'Promote QA_USER_2 to admin from the owner UI'],
  ['roles.admin-permissions', 'Verify admin moderation permissions and real-time role display'],
  ['roles.member-restrictions', 'Verify a normal member cannot grant admin or kick members'],
  ['roles.owner-only', 'Verify owner-only controls stay unavailable to non-owners'],
  ['roles.revoke-admin', 'Revoke QA_USER_2 admin rights and verify access is removed'],
  ['roles.expiry', 'Verify temporary admin permissions expire when supported'],
  ['pranks.shake', 'Test room screen-shake delivery to the intended QA clients'],
  ['pranks.jumpscare', 'Test personal jumpscare image upload, delivery and expiration'],
  ['pranks.image-validation', 'Test invalid and oversized prank images'],
  ['pranks.permissions', 'Verify prank tools respect room roles and permissions'],
  ['lobby.uno-create-join', 'Create a shared UNO lobby and join with multiple QA accounts'],
  ['lobby.uno-ready', 'Test ready/unready and real-time player-list updates'],
  ['lobby.leave-transfer', 'Test lobby member leave and host transfer'],
  ['lobby.countdown', 'Test ready/unready and leave actions during countdown'],
  ['lobby.refresh', 'Refresh clients during a lobby and detect ghost/duplicate players'],
  ['uno.match', 'Play a complete multiplayer UNO match'],
  ['uno.rules-private-hands', 'Test card legality, turn order, draw/special cards and private hands'],
  ['uno.reconnect-results', 'Test UNO disconnect/reconnect, winner, results and next round'],
  ['vampir.real-players', 'Run Vampir Köylü with five real QA accounts'],
  ['vampir.roles-private', 'Verify Vampir/Doktor/Köylü roles remain private'],
  ['vampir.phases-votes', 'Test night, discussion, voting, timer and tie behavior'],
  ['vampir.victory-results', 'Test both victory conditions, results and lobby return'],
  ['vampir.reconnect', 'Test refresh/disconnect during every Vampir Köylü phase'],
  ['bots.target-5', 'Test one human plus four server-side bots (target 5)'],
  ['bots.target-8', 'Test one human plus seven server-side bots (target 8)'],
  ['bots.target-12', 'Test one human plus eleven server-side bots (target 12)'],
  ['bots.permissions', 'Verify only the host can change bot settings'],
  ['bots.actions', 'Verify bots take valid actions and the game completes'],
  ['security.private-room', 'Verify non-members cannot read private room content'],
  ['security.profiles', 'Verify members cannot edit or impersonate another profile'],
  ['security.owner-admin', 'Verify owner/admin boundaries and member restrictions'],
  ['security.private-game-data', 'Verify UNO hands and Vampir roles are private'],
  ['security.room-isolation', 'Verify messages and game sessions do not leak between rooms'],
  ['security.leave-revokes', 'Verify leaving a room removes access as intended'],
];

const results = new Map(PLAN.map(([id, name]) => [id, {
  id,
  name,
  status: 'pending',
  details: '',
  evidence: []
}]));
const browserLogs = new Map();
let credentials;
let privateValues = [];
let browser;
let contexts = [];
let roomInviteCode = '';
let createdRoomNames = [];
let createdGameSessions = [];
let closedGameSessions = [];
let cleanedUpRoomNames = [];
let primaryQaRoomName = '';

function uniqueUsername(index, used) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const username = `qa${randomBytes(5).toString('hex').slice(0, 8)}${index}`;
    if (/^[a-zA-Z0-9_]{3,20}$/.test(username) && !used.has(username.toLowerCase())) {
      used.add(username.toLowerCase());
      return username;
    }
  }
  throw new Error('Could not generate a unique CACA username.');
}

function generateAccounts() {
  const used = new Set();
  return Array.from({ length: 5 }, (_, i) => ({
    alias: `QA_USER_${i + 1}`,
    username: uniqueUsername(i + 1, used),
    password: randomBytes(32).toString('base64url'),
    created: false
  }));
}

async function saveCredentials() {
  await fs.mkdir(PRIVATE, { recursive: true, mode: 0o700 });
  await fs.mkdir(AUTH_STATE, { recursive: true, mode: 0o700 });
  const temporary = `${CREDENTIALS_FILE}.tmp`;
  await fs.writeFile(temporary, `${JSON.stringify({ schemaVersion: 1, createdAt: new Date().toISOString(), accounts: credentials }, null, 2)}\n`, { mode: 0o600 });
  await fs.rename(temporary, CREDENTIALS_FILE);
  try { await fs.chmod(CREDENTIALS_FILE, 0o600); } catch { /* Windows ACLs are inherited from the private directory. */ }
}

async function loadCredentials() {
  await fs.mkdir(PRIVATE, { recursive: true, mode: 0o700 });
  await fs.mkdir(AUTH_STATE, { recursive: true, mode: 0o700 });
  try {
    const parsed = JSON.parse(await fs.readFile(CREDENTIALS_FILE, 'utf8'));
    if (!Array.isArray(parsed.accounts) || parsed.accounts.length !== 5) {
      throw new Error('private/credentials.json must contain exactly five QA accounts.');
    }
    const seen = new Set();
    for (let i = 0; i < 5; i += 1) {
      const account = parsed.accounts[i];
      if (account.alias !== `QA_USER_${i + 1}` || !/^[a-zA-Z0-9_]{3,20}$/.test(account.username) || account.password.length < 12) {
        throw new Error('The private credentials file has an invalid account entry.');
      }
      const normalized = account.username.toLowerCase();
      if (seen.has(normalized)) throw new Error('The private credentials file contains duplicate usernames.');
      seen.add(normalized);
    }
    credentials = parsed.accounts;
    privateValues = credentials.flatMap((a) => [a.username, a.password]);
    try { await fs.chmod(CREDENTIALS_FILE, 0o600); } catch { /* Windows ACLs are inherited from the private directory. */ }
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    credentials = generateAccounts();
    privateValues = credentials.flatMap((a) => [a.username, a.password]);
    await saveCredentials();
    console.log('Generated five private QA identities. Credentials are stored only in private/credentials.json.');
  }
}

function scrub(value) {
  let text = String(value ?? '');
  for (const secret of privateValues.filter(Boolean).sort((a, b) => b.length - a.length)) {
    text = text.split(secret).join('[REDACTED]');
  }
  if (roomInviteCode) text = text.split(roomInviteCode).join('[INVITE_CODE]');
  return text.replace(/[\r\n]+/g, ' ').slice(0, 1600);
}

function record(id, status, details = '', evidence = []) {
  const current = results.get(id);
  if (!current) throw new Error(`Unknown test ID: ${id}`);
  current.status = status;
  current.details = scrub(details);
  current.evidence = evidence.map(scrub);
}

function blockPending(reason) {
  for (const [id, item] of results) {
    if (item.status === 'pending') record(id, 'blocked', reason);
  }
}

function counts() {
  const values = [...results.values()];
  return {
    total: values.length,
    passed: values.filter((x) => x.status === 'passed').length,
    failed: values.filter((x) => x.status === 'failed').length,
    partial: values.filter((x) => x.status === 'partial').length,
    blocked: values.filter((x) => x.status === 'blocked').length,
    pending: values.filter((x) => x.status === 'pending').length
  };
}

function isNetworkBlocked(error) {
  return /ERR_BLOCKED_BY_ADMINISTRATOR|ERR_NAME_NOT_RESOLVED|ENOTFOUND|EAI_AGAIN|ERR_INTERNET_DISCONNECTED|ERR_TUNNEL_CONNECTION_FAILED|ETIMEDOUT|timed out|net::ERR_/i.test(String(error?.message || error));
}

function attachLogging(page, alias) {
  page.__qaAlias = alias;
  const events = [];
  browserLogs.set(alias, events);
  page.on('console', (message) => {
    if (message.type() === 'error' || message.type() === 'warning') {
      events.push({ at: new Date().toISOString(), kind: 'console', level: message.type(), message: scrub(message.text()) });
    }
  });
  page.on('pageerror', (error) => events.push({ at: new Date().toISOString(), kind: 'pageerror', message: scrub(error.message) }));
  page.on('requestfailed', (request) => events.push({ at: new Date().toISOString(), kind: 'requestfailed', url: scrub(request.url()), failure: scrub(request.failure()?.errorText || 'unknown') }));
  page.on('response', (response) => {
    if (response.status() >= 500) events.push({ at: new Date().toISOString(), kind: 'http', status: response.status(), url: scrub(response.url()) });
  });
}

async function persistBrowserLogs() {
  await fs.mkdir(LOG_DIR, { recursive: true });
  for (const [alias, entries] of browserLogs) {
    const file = path.join(LOG_DIR, `${alias.toLowerCase()}.jsonl`);
    await fs.writeFile(file, entries.map((entry) => JSON.stringify(entry)).join('\n') + (entries.length ? '\n' : ''), { mode: 0o600 });
  }
}

async function safeScreenshot(page, name) {
  try {
    await fs.mkdir(SCREENSHOT_DIR, { recursive: true });
    await page.addStyleTag({ content: `
      #welcomeUsername, #accountUsername, #settingsUsername,
      #membersList, #roomsList, #chatMessages, #gamePlayersList,
      #gameSpectatorsList, .room-admin-info, input, textarea, select { filter: blur(7px) !important; }
    ` });
    const file = path.join(SCREENSHOT_DIR, `${name}.png`);
    await page.screenshot({ path: file, fullPage: true, animations: 'disabled', timeout: 12000 });
    return path.relative(ROOT, file);
  } catch {
    return '';
  }
}

async function openPage(context, alias) {
  const page = await context.newPage();
  attachLogging(page, alias);
  await page.goto(BASE_URL, { waitUntil: 'domcontentloaded', timeout: TIMEOUT });
  await page.locator('#authView').waitFor({ state: 'visible', timeout: TIMEOUT });
  return page;
}

async function fillAndSubmitLogin(page, account) {
  await page.locator('#loginTab').click();
  await page.locator('#loginUsername').fill(account.username);
  await page.locator('#loginPassword').fill(account.password);
  await page.locator('#loginForm button[type="submit"]').click();
  await page.locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
}

async function regenerateAccountCredentials(account) {
  const index = credentials.indexOf(account);
  if (index < 0) throw new Error('QA account alias was not found in the private credentials file.');
  const used = new Set(credentials.filter((item) => item !== account).map((item) => item.username.toLowerCase()));
  account.username = uniqueUsername(index + 1, used);
  account.password = randomBytes(32).toString('base64url');
  account.created = false;
  privateValues = credentials.flatMap((item) => [item.username, item.password]);
  await saveCredentials();
}

async function registerOrLogin(page, account) {
  if (account.created) {
    await fillAndSubmitLogin(page, account);
    return 'Logged in using previously registered local QA account.';
  }

  for (let attempt = 0; attempt < 6; attempt += 1) {
    await page.locator('#registerTab').click();
    await page.locator('#registerUsername').fill(account.username);
    await page.locator('#registerPassword').fill(account.password);
    await page.locator('#registerForm button[type="submit"]').click();

    try {
      await page.locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
      account.created = true;
      await saveCredentials();
      return 'Registered through the normal CACA username/password UI.';
    } catch (registrationError) {
      const message = await page.locator('#authMessage').innerText().catch(() => '');
      if (/zaten alınmış|already in use|already exists/i.test(message)) {
        // Recover an interrupted previous attempt first. A successful login means the
        // current private credentials already belong to this QA account.
        try {
          await fillAndSubmitLogin(page, account);
          account.created = true;
          await saveCredentials();
          return 'Recovered an account from a previous interrupted run by logging in with its private credentials.';
        } catch {
          // Collision with an unrelated existing username: rotate to a fresh random
          // username and password, persisting both privately before retrying.
          if (attempt < 5) {
            await regenerateAccountCredentials(account);
            continue;
          }
        }
      }
      throw new Error(`Registration did not complete: ${message || registrationError.message}`);
    }
  }
  throw new Error('Registration exhausted its unique-username retry limit.');
}

async function waitForAuthSubmissionToFinish(page) {
  await page.waitForFunction(() => {
    const button = document.querySelector('#registerForm button[type="submit"]');
    const message = document.querySelector('#authMessage')?.textContent?.trim() || '';
    return Boolean(button && !button.disabled && message && message !== 'Hesabın oluşturuluyor...');
  }, null, { timeout: TIMEOUT });
}

async function testAuthNegativeCases() {
  const context = await browser.newContext();
  try {
    const page = await openPage(context, 'NEGATIVE_CASES');

    // A duplicate check is safe only after QA_USER_1 is confirmed to exist.
    if (!credentials[0].created) {
      record('accounts.duplicate', 'blocked', 'Skipped because QA_USER_1 was not registered; duplicate testing is guarded to avoid accidentally creating a sixth account.');
    } else {
      try {
        await page.locator('#registerTab').click();
        await page.locator('#registerUsername').fill(credentials[0].username);
        await page.locator('#registerPassword').fill(randomBytes(24).toString('base64url'));
        await page.locator('#registerForm button[type="submit"]').click();
        await waitForAuthSubmissionToFinish(page);
        const duplicateMessage = (await page.locator('#authMessage').innerText()).trim();
        const dashboardVisible = await page.locator('#appView').isVisible();
        if (!/zaten alınmış|already in use|already exists/i.test(duplicateMessage) || dashboardVisible) {
          throw new Error(`Duplicate username response was not a clear rejection. UI message: ${duplicateMessage || '[empty]'}`);
        }
        record('accounts.duplicate', 'passed', 'Duplicate username was rejected after the registration request finished; no additional account was created.');
      } catch (error) {
        record('accounts.duplicate', isNetworkBlocked(error) ? 'blocked' : 'failed', error.message);
        const screenshot = await safeScreenshot(page, 'duplicate-username-failure');
        if (screenshot) results.get('accounts.duplicate').evidence.push(screenshot);
      }
    }

    // Short password: HTML minlength=8 must prevent normal form submission.
    try {
      await page.locator('#registerTab').click();
      await page.locator('#registerUsername').fill(`qaweak${randomBytes(4).toString('hex')}`);
      const weakPassword = 'QA1!xyz'; // exactly 7 characters
      await page.locator('#registerPassword').fill(weakPassword);
      const validation = await page.locator('#registerPassword').evaluate((el) => ({
        minLength: el.minLength,
        valueLength: el.value.length,
        valid: el.form.checkValidity()
      }));
      await page.locator('#registerForm button[type="submit"]').click();
      if (validation.minLength !== 8 || validation.valueLength !== 7 || validation.valid || await page.locator('#appView').isVisible()) {
        throw new Error('A 7-character password was not blocked by the registration form minlength validation.');
      }
      record('accounts.short-password', 'passed', 'A 7-character password was rejected by the browser form minlength=8 constraint; no registration was submitted.');
    } catch (error) {
      record('accounts.short-password', isNetworkBlocked(error) ? 'blocked' : 'failed', error.message);
    }

    // Invalid login: one low-volume negative attempt using a known QA username.
    if (!credentials[0].created) {
      record('accounts.invalid-login', 'blocked', 'Skipped because no registered QA identity is available for a safe invalid-password check.');
    } else {
      try {
        await page.locator('#loginTab').click();
        await page.locator('#loginUsername').fill(credentials[0].username);
        await page.locator('#loginPassword').fill(randomBytes(24).toString('base64url'));
        await page.locator('#loginForm button[type="submit"]').click();
        await page.waitForFunction(() => {
          const button = document.querySelector('#loginForm button[type="submit"]');
          const message = document.querySelector('#authMessage')?.textContent?.trim() || '';
          return Boolean(button && !button.disabled && message && message !== 'Giriş yapılıyor...');
        }, null, { timeout: TIMEOUT });
        if (await page.locator('#appView').isVisible()) throw new Error('Invalid login unexpectedly opened the dashboard.');
        record('accounts.invalid-login', 'passed', 'Invalid password was rejected; the account remained logged out.');
      } catch (error) {
        record('accounts.invalid-login', isNetworkBlocked(error) ? 'blocked' : 'failed', error.message);
      }
    }
  } finally {
    await context.close();
  }
}

async function testAccountSessions(pages) {
  const authenticated = await Promise.all(pages.map(async (page) => Boolean(page && await page.locator('#appView').isVisible().catch(() => false))));
  if (authenticated.every(Boolean)) {
    record('accounts.concurrent', 'passed', 'Five independent browser contexts remained authenticated at the same time.');
  } else {
    record('accounts.concurrent', 'failed', `${authenticated.filter(Boolean).length} of five QA contexts were authenticated concurrently.`);
  }

  const logoutResults = [];
  const refreshResults = [];
  const reopenResults = [];
  for (let i = 0; i < 5; i += 1) {
    const page = pages[i];
    const account = credentials[i];
    if (!page || !authenticated[i]) continue;
    try {
      await page.locator('#logoutButton').click();
      await page.locator('#authView').waitFor({ state: 'visible', timeout: TIMEOUT });
      if (await page.locator('#appView').isVisible()) throw new Error('Dashboard remained visible after logout.');
      await fillAndSubmitLogin(page, account);
      logoutResults.push(true);
    } catch (error) {
      logoutResults.push(false);
      browserLogs.get(account.alias)?.push({ at: new Date().toISOString(), kind: 'auth-test-error', message: scrub(error.message) });
    }

    try {
      await page.reload({ waitUntil: 'domcontentloaded', timeout: TIMEOUT });
      await page.locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
      refreshResults.push(true);
    } catch (error) {
      refreshResults.push(false);
      browserLogs.get(account.alias)?.push({ at: new Date().toISOString(), kind: 'refresh-test-error', message: scrub(error.message) });
    }

    try {
      const stateFile = path.join(AUTH_STATE, `${account.alias.toLowerCase()}.json`);
      await contexts[i].storageState({ path: stateFile, indexedDB: true });
      try { await fs.chmod(stateFile, 0o600); } catch { /* Windows ACLs inherited from private directory. */ }
      const reopenedContext = await browser.newContext({ storageState: stateFile });
      const reopenedPage = await openPage(reopenedContext, `${account.alias}_REOPEN`);
      await reopenedPage.locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
      await reopenedContext.close();
      reopenResults.push(true);
    } catch (error) {
      reopenResults.push(false);
      browserLogs.get(account.alias)?.push({ at: new Date().toISOString(), kind: 'reopen-test-error', message: scrub(error.message) });
    }
  }

  record('accounts.logout-login', logoutResults.length === 5 && logoutResults.every(Boolean) ? 'passed' : 'failed', `${logoutResults.filter(Boolean).length} of five accounts passed logout and successful login.`);
  record('accounts.refresh', refreshResults.length === 5 && refreshResults.every(Boolean) ? 'passed' : 'failed', `${refreshResults.filter(Boolean).length} of five accounts remained authenticated after refresh.`);
  record('accounts.reopen', reopenResults.length === 5 && reopenResults.every(Boolean) ? 'passed' : 'failed', `${reopenResults.filter(Boolean).length} of five accounts restored an authenticated session in a new browser context.`);
}

async function runCase(id, page, action) {
  const alias = page?.__qaAlias;
  const logStart = alias ? (browserLogs.get(alias)?.length || 0) : 0;
  try {
    const details = await action();
    record(id, 'passed', details || 'UI test passed.');
    return true;
  } catch (error) {
    const text = String(error?.message || error);
    const recentLogs = alias ? (browserLogs.get(alias) || []).slice(logStart) : [];
    const firebaseLogs = recentLogs
      .filter((entry) => /permission-denied|failed-precondition|Missing or insufficient permissions/i.test(entry.message || ''))
      .map((entry) => entry.message);
    const uiMessages = page
      ? await page.locator('#gameCenterStatus, #gameSessionStatus').allTextContents().catch(() => [])
      : [];
    const diagnostic = [...uiMessages, ...firebaseLogs].map((value) => String(value || '').trim()).filter(Boolean).join(' | ');
    const combined = diagnostic ? `${text} | App diagnostic: ${diagnostic}` : text;
    const appRejected = /permission-denied|failed-precondition|Missing or insufficient permissions|Firestore Rules güncel/i.test(combined);
    const automationOnly = /Timeout .* exceeded|intercepts pointer events|not visible|not attached|strict mode violation/i.test(text);
    const status = isNetworkBlocked(error) ? 'blocked' : appRejected ? 'failed' : automationOnly ? 'partial' : 'failed';
    record(id, status, combined);
    const screenshot = page ? await safeScreenshot(page, `${id.replace(/[^a-z0-9]+/gi, '-')}-failure`) : '';
    if (screenshot) results.get(id).evidence.push(screenshot);
    return false;
  }
}

async function closeRoomDialogs(page) {
  if (await page.locator('#settingsView').isVisible().catch(() => false)) {
    await page.locator('#backFromSettings').click().catch(() => {});
    await page.locator('#settingsView').waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
  }
  const pairs = [
    ['#jumpscarePanel', '#closeJumpscarePanelButton'],
    ['#gameCenterPanel', '#closeGameCenterButton'],
    ['#adminPanel', '#closeAdminPanelButton'],
    ['#roomManagementPanel', '#closeRoomManagementButton'],
    ['#gameLobbySettingsPanel', '#closeGameLobbySettingsButton']
  ];
  for (const [panel, close] of pairs) {
    if (await page.locator(panel).isVisible().catch(() => false)) {
      await page.locator(close).click({ timeout: 5000 }).catch(() => {});
      await page.locator(panel).waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {});
    }
  }
}

async function openGameCenter(page) {
  await closeRoomDialogs(page);
  if (!(await page.locator('#gameCenterPanel').isVisible().catch(() => false))) {
    await page.locator('#funCenterOpenButton').click({ timeout: TIMEOUT });
  }
  await page.locator('#gameCenterPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
}

async function createQaRoom(page, name) {
  await page.locator('#backToDashboard').click().catch(() => {});
  await page.locator('#dashboardView').waitFor({ state: 'visible', timeout: TIMEOUT });
  await page.locator('#newRoomName').fill(name);
  await page.locator('#createRoomForm button[type="submit"]').click();
  await page.locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
  await page.waitForFunction(() => Boolean(document.querySelector('#activeRoomCode')?.textContent?.trim()), null, { timeout: TIMEOUT });
  return (await page.locator('#activeRoomCode').innerText()).trim();
}

async function openSettings(page) {
  await page.locator('#settingsButton').click();
  await page.locator('#settingsView').waitFor({ state: 'visible', timeout: TIMEOUT });
}

async function openMessageMenu(page, messageText) {
  const row = page.locator('.message-row').filter({ hasText: messageText }).last();
  await row.waitFor({ state: 'visible', timeout: TIMEOUT });
  await row.locator('.message-more-button').click();
  await row.locator('.message-action-menu').waitFor({ state: 'visible', timeout: TIMEOUT });
  return row;
}

async function testRoomChatAndRoles(pages) {
  const roomName = `QA-${RUN_ID.slice(-8)}`;
  primaryQaRoomName = roomName;
  const owner = pages[0];
  const expectedNames = credentials.map((a) => a.username);

  // Create and populate one isolated QA room using only the five dedicated test identities.
  try {
    await owner.locator('#createRoomForm').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.locator('#newRoomName').fill(roomName);
    await owner.locator('#createRoomForm button[type="submit"]').click();
    await owner.locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.waitForFunction(() => Boolean(document.querySelector('#activeRoomCode')?.textContent?.trim()), null, { timeout: TIMEOUT });
    if (!(await owner.locator('#activeRoomName').innerText()).trim().includes(roomName)) throw new Error('The room UI did not show the unique QA room name after creation.');
    createdRoomNames.push(roomName);
    roomInviteCode = (await owner.locator('#activeRoomCode').innerText()).trim();
    if (!/^[A-HJ-NP-Z2-9]{8}$/.test(roomInviteCode)) throw new Error('Owner UI did not display a valid 8-character invite code.');
    record('rooms.create', 'passed', 'QA_USER_1 created a new QA-only room using the normal room-creation UI.');
  } catch (error) {
    record('rooms.create', isNetworkBlocked(error) ? 'blocked' : 'failed', error.message);
    blockPending('Room setup could not complete; dependent room/chat tests require a QA-only room.');
    return;
  }

  try {
    for (let i = 1; i < 5; i += 1) {
      const page = pages[i];
      await page.locator('details.sidebar-action').nth(1).evaluate((node) => { node.open = true; });
      await page.locator('#roomInviteCode').fill(roomInviteCode);
      await page.locator('#joinRoomForm button[type="submit"]').click();
      await page.locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    }
    record('rooms.join', 'passed', 'QA_USER_2 through QA_USER_5 joined the run-created room through its invite code.');
    await owner.waitForFunction((names) => {
      const text = document.querySelector('#membersList')?.innerText || '';
      return names.slice(1).every((name) => text.includes(name));
    }, expectedNames, { timeout: TIMEOUT });
    record('rooms.members', 'passed', 'The owner client showed all four other QA members in its live member list.');
  } catch (error) {
    for (const id of ['rooms.join', 'rooms.members']) record(id, isNetworkBlocked(error) ? 'blocked' : 'failed', error.message);
    blockPending('The QA room does not have all five users; dependent multi-user tests were skipped.');
    return;
  }

  // Profile nickname and avatar changes are always rolled back in finally blocks.
  await runCase('profiles.nickname', owner, async () => {
    let original = null;
    let opened = false;
    let changed = '';
    try {
      await openSettings(owner);
      opened = true;
      await owner.locator('#nicknameInput').waitFor({ state: 'visible', timeout: TIMEOUT });
      original = await owner.locator('#nicknameInput').inputValue();
      changed = `qaNick${RUN_ID.slice(-5)}`;
      await owner.locator('#nicknameInput').fill(changed);
      await owner.locator('#nicknameForm button[type="submit"]').click();
      await owner.waitForFunction(() => (document.querySelector('#settingsMessage')?.textContent || '').toLowerCase().includes('güncellendi'), null, { timeout: TIMEOUT });
      for (let i = 1; i < 5; i += 1) {
        await pages[i].waitForFunction((value) => (document.querySelector('#membersList')?.innerText || '').includes(value), changed, { timeout: TIMEOUT });
      }
      return 'Nickname update appeared in the other room clients.';
    } finally {
      if (original !== null && opened) {
        await owner.locator('#nicknameInput').fill(original).catch(() => {});
        await owner.locator('#nicknameForm button[type="submit"]').click().catch(() => {});
        await owner.waitForFunction((value) => (document.querySelector('#nicknameInput')?.value || '') === value, original, { timeout: 10000 }).catch(() => {});
      }
      if (opened && await owner.locator('#settingsView').isVisible().catch(() => false)) {
        await owner.locator('#backFromSettings').click().catch(() => {});
      }
    }
  });

  await runCase('profiles.avatar', owner, async () => {
    let opened = false;
    let original = null;
    try {
      await openSettings(owner);
      opened = true;
      original = await owner.locator('#avatarPicker [data-avatar-id][aria-pressed="true"]').getAttribute('data-avatar-id').catch(() => null);
      const avatarIds = await owner.locator('#avatarPicker [data-avatar-id]').evaluateAll((nodes) =>
        nodes.map((node) => node.getAttribute('data-avatar-id')).filter(Boolean)
      );
      const next = avatarIds.find((id) => id !== original);
      if (!next) throw new Error('The avatar picker did not expose a second selectable standard avatar.');
      await owner.locator(`#avatarPicker [data-avatar-id="${next}"]`).click();
      await owner.waitForFunction((value) => {
        const selected = document.querySelector('#avatarPicker [data-avatar-id][aria-pressed="true"]');
        const save = document.querySelector('#saveAvatarButton');
        return selected?.getAttribute('data-avatar-id') === value && save && !save.disabled;
      }, next, { timeout: TIMEOUT });
      await owner.locator('#saveAvatarButton').click();
      await owner.waitForFunction((value) => {
        const selected = document.querySelector('#avatarPicker [data-avatar-id][aria-pressed="true"]');
        return selected?.getAttribute('data-avatar-id') === value && /kaydedildi|güncellendi/i.test(document.querySelector('#avatarSaveMessage')?.textContent || '');
      }, next, { timeout: TIMEOUT });
      return 'A standard avatar was saved through account settings.';
    } finally {
      if (opened && original) {
        await owner.locator(`#avatarPicker [data-avatar-id="${original}"]`).click().catch(() => {});
        await owner.locator('#saveAvatarButton').click().catch(() => {});
        await owner.waitForFunction((value) => document.querySelector(`#avatarPicker [data-avatar-id="${value}"]`)?.getAttribute('aria-pressed') === 'true', original, { timeout: 10000 }).catch(() => {});
      }
      if (opened && await owner.locator('#settingsView').isVisible().catch(() => false)) {
        await owner.locator('#backFromSettings').click().catch(() => {});
      }
    }
  });

  // Real-time message fan-out across five isolated browser contexts.
  const messages = [];
  await runCase('chat.realtime', owner, async () => {
    for (let i = 0; i < 5; i += 1) {
      const body = `CACA-QA ${credentials[i].alias} Türkçe ğüşiöç İı 😀 🚀 ${RUN_ID}`;
      messages.push(body);
      await pages[i].locator('#chatInput').fill(body);
      await pages[i].locator('#chatForm button[type="submit"]').click();
      await pages[i].waitForFunction((value) => (document.querySelector('#chatMessages')?.innerText || '').includes(value), body, { timeout: TIMEOUT });
    }
    for (const page of pages) {
      await page.waitForFunction((all) => {
        const text = document.querySelector('#chatMessages')?.innerText || '';
        return all.every((message) => text.includes(message));
      }, messages, { timeout: TIMEOUT });
    }
    return 'Each of the five accounts sent one uniquely tagged Turkish/emoji message; all five clients rendered all five messages.';
  });

  await runCase('chat.turkish-emoji-long', pages[0], async () => {
    const longMessage = (`Uzun mesaj testi ğüşiöç 😀 🚀 ${RUN_ID} `).repeat(45).slice(0, 1800);
    await pages[0].locator('#chatInput').fill(longMessage);
    await pages[0].locator('#chatForm button[type="submit"]').click();
    await pages[1].waitForFunction((value) => (document.querySelector('#chatMessages')?.innerText || '').includes(value), longMessage, { timeout: TIMEOUT });
    return 'An 1,800-character message containing Turkish characters and emoji was accepted and appeared in another session.';
  });

  let editedMessage = `EDIT-ME-${RUN_ID}`;
  await runCase('chat.edit-own', pages[1], async () => {
    await pages[1].locator('#chatInput').fill(editedMessage);
    await pages[1].locator('#chatForm button[type="submit"]').click();
    await pages[1].waitForFunction((value) => (document.querySelector('#chatMessages')?.innerText || '').includes(value), editedMessage, { timeout: TIMEOUT });
    const row = await openMessageMenu(pages[1], editedMessage);
    await row.locator('.message-action-menu').getByText('Düzenle', { exact: true }).click();
    const replacement = `EDITED-${RUN_ID}`;
    await row.locator('textarea[aria-label="Mesajı düzenle"]').fill(replacement);
    await row.locator('.message-edit-save').click();
    await pages[1].waitForFunction((value) => (document.querySelector('#chatMessages')?.innerText || '').includes(value), replacement, { timeout: TIMEOUT });
    editedMessage = replacement;
    return 'The sender edited their own chat message using the message menu; the updated text appeared in the sender client.';
  });

  await runCase('chat.delete-own', pages[1], async () => {
    const deletion = `DELETE-ME-${RUN_ID}`;
    await pages[1].locator('#chatInput').fill(deletion);
    await pages[1].locator('#chatForm button[type="submit"]').click();
    await pages[1].waitForFunction((value) => (document.querySelector('#chatMessages')?.innerText || '').includes(value), deletion, { timeout: TIMEOUT });
    const row = await openMessageMenu(pages[1], deletion);
    pages[1].once('dialog', (dialog) => dialog.accept());
    await row.locator('.message-action-menu').getByText('Mesajı sil', { exact: true }).click();
    await pages[1].waitForFunction((value) => !(document.querySelector('#chatMessages')?.innerText || '').includes(value), deletion, { timeout: TIMEOUT });
    return 'The sender deleted their own QA message; it disappeared from the chat UI.';
  });

  await runCase('chat.prevent-edit-other', pages[2], async () => {
    const row = pages[2].locator('.message-row').filter({ hasText: messages[0] }).last();
    await row.waitFor({ state: 'visible', timeout: TIMEOUT });
    if (await row.locator('.message-actions').count()) throw new Error('A non-owner member unexpectedly received message action controls for another user’s message.');
    return 'A normal member did not receive edit controls for another QA user’s message.';
  });
  await runCase('chat.prevent-delete-other', pages[2], async () => {
    const row = pages[2].locator('.message-row').filter({ hasText: messages[0] }).last();
    await row.waitFor({ state: 'visible', timeout: TIMEOUT });
    if (await row.locator('.message-actions').count()) throw new Error('A non-owner member unexpectedly received delete controls for another user’s message.');
    return 'A normal member did not receive delete controls for another QA user’s message.';
  });

  await runCase('chat.history-refresh', pages[2], async () => {
    await pages[2].reload({ waitUntil: 'domcontentloaded', timeout: TIMEOUT });
    await pages[2].locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[2].locator('#roomsList').getByText(roomName, { exact: true }).click();
    await pages[2].locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[2].waitForFunction((value) => (document.querySelector('#chatMessages')?.innerText || '').includes(value), messages[0], { timeout: TIMEOUT });
    return 'After refreshing, QA_USER_3 reopened the room and saw an earlier message.';
  });

  // Owner/admin/member role boundaries and reversible role changes.
  await runCase('roles.promote-admin', owner, async () => {
    await closeRoomDialogs(owner);
    await owner.locator('#roomManagementButton').click();
    await owner.locator('#roomManagementPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    const target = owner.locator('#adminTargetSelect option').filter({ hasText: credentials[1].username }).first();
    const targetValue = await target.getAttribute('value');
    if (!targetValue) throw new Error('QA_USER_2 was not present in the owner admin selector.');
    await owner.locator('#adminTargetSelect').selectOption(targetValue);
    await owner.locator('#adminDurationSelect').selectOption('permanent');
    await owner.locator('#grantAdminButton').click();
    await owner.waitForFunction(() => (document.querySelector('#adminManagementStatus')?.innerText || '').includes('Kalıcı yönetici yetkisi verildi'), null, { timeout: TIMEOUT });
    await pages[1].locator('#adminPanelButton').waitFor({ state: 'visible', timeout: TIMEOUT });
    return 'The owner promoted QA_USER_2 through the room management panel.';
  });

  await runCase('roles.admin-permissions', pages[1], async () => {
    if (!(await pages[1].locator('#adminPanelButton').isVisible())) throw new Error('QA_USER_2 did not receive admin panel access.');
    if (await pages[2].locator('#adminPanelButton').isVisible()) throw new Error('QA_USER_3 unexpectedly received admin panel access.');
    await pages[1].locator('#adminPanelButton').click();
    await pages[1].locator('#adminPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[1].locator('#closeAdminPanelButton').click();
    return 'QA_USER_2 received admin tools; QA_USER_3 did not.';
  });

  await runCase('roles.member-restrictions', pages[2], async () => {
    if (await pages[2].locator('#adminPanelButton').isVisible()) throw new Error('Normal member can see the admin panel button.');
    if (await pages[2].locator('#roomManagementButton').isVisible()) throw new Error('Normal member can see owner management controls.');
    return 'Normal member UI did not expose admin or owner management controls.';
  });
  await runCase('roles.owner-only', owner, async () => {
    if (!(await owner.locator('#roomManagementButton').isVisible())) throw new Error('Owner management control was not visible to the owner.');
    if (await pages[2].locator('#roomManagementButton').isVisible()) throw new Error('Owner management control was visible to a normal member.');
    return 'Owner management controls were visible to QA_USER_1 and hidden from ordinary members.';
  });

  await runCase('pranks.shake', pages[1], async () => {
    await closeRoomDialogs(pages[1]);
    await pages[1].locator('#adminPanelButton').click();
    await pages[1].locator('#adminPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[1].locator('#shakeButton').click();
    await owner.waitForFunction(() => document.body.classList.contains('room-screen-shake'), null, { timeout: TIMEOUT });
    await pages[1].locator('#closeAdminPanelButton').click();
    return 'Admin-triggered screen shake reached the room owner client.';
  });

  await runCase('roles.revoke-admin', owner, async () => {
    await closeRoomDialogs(owner);
    await owner.locator('#roomManagementButton').click();
    await owner.locator('#roomManagementPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    owner.once('dialog', (dialog) => dialog.accept());
    await owner.locator('#roomAdminsList .admin-revoke-button').click();
    await owner.waitForFunction(() => (document.querySelector('#roomAdminsList')?.innerText || '').includes('Henüz atanmış yönetici yok'), null, { timeout: TIMEOUT });
    await pages[1].locator('#adminPanelButton').waitFor({ state: 'hidden', timeout: TIMEOUT });
    return 'Owner revoked QA_USER_2 admin rights; the admin button disappeared from that account.';
  });

  await runCase('roles.expiry', owner, async () => {
    await closeRoomDialogs(owner);
    await owner.locator('#roomManagementButton').click();
    await owner.locator('#roomManagementPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    const target = owner.locator('#adminTargetSelect option').filter({ hasText: credentials[1].username }).first();
    const targetValue = await target.getAttribute('value');
    if (!targetValue) throw new Error('QA_USER_2 was not available for a timed admin grant.');
    await owner.locator('#adminTargetSelect').selectOption(targetValue);
    await owner.locator('#adminDurationSelect').selectOption({ label: '5 saniye' });
    await owner.locator('#grantAdminButton').click();
    await owner.waitForFunction(() => (document.querySelector('#adminManagementStatus')?.innerText || '').includes('Süreli yönetici yetkisi verildi'), null, { timeout: TIMEOUT });
    await pages[1].locator('#adminPanelButton').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[1].locator('#adminPanelButton').waitFor({ state: 'hidden', timeout: 15000 });
    return 'A five-second temporary admin grant expired and QA_USER_2 lost admin UI access.';
  });

  // Owner-only private jumpscare library, delivery to a normal QA member, and expiration.
  await runCase('pranks.jumpscare', owner, async () => {
    await closeRoomDialogs(owner);
    await owner.locator('#adminPanelButton').click();
    await owner.locator('#adminPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.locator('#jumpscareOpenButton').click();
    await owner.locator('#jumpscarePanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    const imagePath = path.join(ROOT, 'fixtures', 'qa-image.png');
    await owner.locator('#jumpscareSlotFile1').setInputFiles(imagePath);
    await owner.locator('#jumpscareCropDialog').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.locator('#saveJumpscareCropButton').click();
    await owner.locator('#jumpscareCropDialog').waitFor({ state: 'hidden', timeout: TIMEOUT });
    await owner.waitForFunction(() => /kadrajı kaydedildi/i.test(document.querySelector('#jumpscareLibraryStatus')?.textContent || ''), null, { timeout: TIMEOUT });
    await owner.locator('#jumpscareDurationSelect').selectOption({ label: '3 saniye' });
    const target = owner.locator('#jumpscareTargetSelect option').filter({ hasText: credentials[2].username }).first();
    const targetValue = await target.getAttribute('value');
    if (!targetValue) throw new Error('A normal QA member was not available as a jumpscare recipient.');
    await owner.locator('#jumpscareTargetSelect').selectOption(targetValue);
    await owner.locator('#sendPersonalJumpscareButton').click();
    await pages[2].locator('#roomPrankOverlay').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[2].locator('#roomPrankOverlay').waitFor({ state: 'hidden', timeout: 9000 });
    await owner.locator('#jumpscareSlotClear1').click();
    await owner.locator('#jumpscareSlotEmpty1').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.locator('#closeJumpscarePanelButton').click();
    await owner.locator('#closeAdminPanelButton').click();
    return 'A test image was saved to the QA owner’s private library, delivered to QA_USER_3, auto-expired, and removed from the test library.';
  });

  await runCase('pranks.image-validation', owner, async () => {
    await closeRoomDialogs(owner);
    await owner.locator('#adminPanelButton').click();
    await owner.locator('#jumpscareOpenButton').click();
    await owner.locator('#jumpscarePanel').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.locator('#jumpscareSlotFile2').setInputFiles(path.join(ROOT, 'fixtures', 'not-an-image.txt'));
    await owner.waitForFunction(() => /Yalnızca PNG, JPG veya WebP|formatında/i.test(document.querySelector('#jumpscareLibraryStatus')?.textContent || ''), null, { timeout: TIMEOUT });
    const oversized = Buffer.concat([Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADUlEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC', 'base64'), Buffer.alloc(12 * 1024 * 1024 + 1)]);
    await owner.locator('#jumpscareSlotFile3').setInputFiles({ name: 'oversized.png', mimeType: 'image/png', buffer: oversized });
    await owner.waitForFunction(() => /12 MB|küçük olmalı/i.test(document.querySelector('#jumpscareLibraryStatus')?.textContent || ''), null, { timeout: TIMEOUT });
    await owner.locator('#closeJumpscarePanelButton').click();
    await owner.locator('#closeAdminPanelButton').click();
    return 'A non-image file and a file larger than the documented 12 MB input limit were rejected by the upload UI.';
  });

  await runCase('pranks.permissions', pages[2], async () => {
    if (await pages[2].locator('#adminPanelButton').isVisible()) throw new Error('Normal member can open the prank/admin tool panel.');
    if (await pages[2].locator('#jumpscareOpenButton').isVisible()) throw new Error('Normal member can open the personal jumpscare UI.');
    return 'A normal member did not receive the admin or personal-jumpscare UI controls.';
  });

  // Leave/rejoin uses the actual confirmation dialog. The last run omitted this and timed out.
  await runCase('rooms.leave-rejoin', pages[4], async () => {
    pages[4].once('dialog', (dialog) => dialog.accept());
    await pages[4].locator('#leaveRoomButton').click();
    await pages[4].locator('#dashboardView').waitFor({ state: 'visible', timeout: TIMEOUT });
    const listed = await pages[4].locator('#roomsList').getByText(roomName, { exact: true }).count();
    if (listed !== 0) throw new Error('The room remained in the member room list after leaving.');
    await pages[4].locator('details.sidebar-action').nth(1).evaluate((node) => { node.open = true; });
    await pages[4].locator('#roomInviteCode').fill(roomInviteCode);
    await pages[4].locator('#joinRoomForm button[type="submit"]').click();
    await pages[4].locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    return 'QA_USER_5 accepted the leave confirmation, returned to the dashboard, disappeared from the owner’s member list, then rejoined with the invite code.';
  });

  await runCase('security.private-room', pages[4], async () => {
    pages[4].once('dialog', (dialog) => dialog.accept());
    await pages[4].locator('#leaveRoomButton').click();
    await pages[4].locator('#dashboardView').waitFor({ state: 'visible', timeout: TIMEOUT });
    if (await pages[4].locator('#roomsList').getByText(roomName, { exact: true }).count()) throw new Error('A non-member still sees the private QA room in their room list.');
    if (await pages[4].locator('#roomView').isVisible()) throw new Error('A non-member still has the private room view open.');
    await owner.waitForFunction((name) => !(document.querySelector('#membersList')?.innerText || '').includes(name), credentials[4].username, { timeout: TIMEOUT });
    record('security.leave-revokes', 'passed', 'After leaving, QA_USER_5 disappeared from the room member list and the room was no longer listed for that account.');
    // Rejoin so subsequent shared-game tests still have five QA members.
    await pages[4].locator('details.sidebar-action').nth(1).evaluate((node) => { node.open = true; });
    await pages[4].locator('#roomInviteCode').fill(roomInviteCode);
    await pages[4].locator('#joinRoomForm button[type="submit"]').click();
    await pages[4].locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    return 'A user who left no longer saw the QA room or its room view; the test account rejoined afterwards.';
  });

  await runCase('security.profiles', pages[2], async () => {
    await openSettings(pages[2]);
    const username = await pages[2].locator('#settingsUsername').inputValue();
    const isReadonly = await pages[2].locator('#settingsUsername').isDisabled().catch(() => false) || await pages[2].locator('#settingsUsername').getAttribute('readonly') !== null;
    if (username !== credentials[2].username || !isReadonly) throw new Error('Profile settings do not restrict the account username field to the signed-in account.');
    if (await pages[2].locator('#deleteAccountForm').count() === 0) throw new Error('Expected account settings form was missing.');
    await pages[2].locator('#backFromSettings').click();
    return 'Account settings displayed only the signed-in user’s read-only username; no UI path to edit another user’s profile was present.';
  });

  await runCase('security.owner-admin', owner, async () => {
    if (!(await owner.locator('#roomManagementButton').isVisible())) throw new Error('Owner management UI missing.');
    if (await pages[2].locator('#roomManagementButton').isVisible() || await pages[2].locator('#adminPanelButton').isVisible()) throw new Error('Ordinary member retained privileged UI controls.');
    return 'Owner/admin/member UI boundaries remained distinct after role revocation.';
  });

  // Create and delete a second QA-only room through the room owner UI. No existing room is selected.
  await runCase('rooms.second-delete', owner, async () => {
    await closeRoomDialogs(owner);
    await owner.locator('#backToDashboard').click();
    await owner.locator('#dashboardView').waitFor({ state: 'visible', timeout: TIMEOUT });
    const secondName = `QA-DEL-${RUN_ID.slice(-6)}`;
    const secondCode = await createQaRoom(owner, secondName);
    if (!(await owner.locator('#activeRoomName').innerText()).trim().includes(secondName)) throw new Error('Second QA room was not opened after creation.');
    createdRoomNames.push(secondName);
    if (!/^[A-HJ-NP-Z2-9]{8}$/.test(secondCode)) throw new Error('Second test room invite code was invalid.');
    // Other accounts remain in the primary QA room and must not see this private second room.
    for (let i = 1; i < 5; i += 1) {
      if (await pages[i].locator('#roomsList').getByText(secondName, { exact: true }).count()) throw new Error('A non-member saw the second private QA room.');
    }
    owner.once('dialog', (dialog) => dialog.accept());
    await owner.locator('#leaveRoomButton').click(); // owner button is labelled “Odayı sil”
    await owner.locator('#dashboardView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await owner.waitForFunction((name) => !(document.querySelector('#roomsList')?.innerText || '').includes(name), secondName, { timeout: TIMEOUT });
    cleanedUpRoomNames.push(secondName);
    // Return to the first QA room before further game tests.
    await owner.locator('#roomsList').getByText(roomName, { exact: true }).click();
    await owner.locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    record('security.room-isolation', 'passed', 'A second QA-only room was not visible in any other QA account’s room list while they were not members.');
    return 'A second QA-only room was created, kept invisible to non-members, and deleted through the owner’s normal “Odayı sil” confirmation UI.';
  });
}

async function selectCatalogGame(page, gameId) {
  await openGameCenter(page);
  await page.locator(`#gameCatalogGrid [data-game-id="${gameId}"]`).click();
  await page.locator('#createGameSessionButton').click();
  await page.locator('#gameSessionContent').waitFor({ state: 'visible', timeout: TIMEOUT });
  await page.waitForFunction((id) => {
    const label = document.querySelector('#gameSessionName')?.textContent || '';
    return id === 'uno' ? /UNO/i.test(label) : /Vampir Köylü/i.test(label);
  }, gameId, { timeout: TIMEOUT });
  createdGameSessions.push(gameId);
}

async function joinSharedGameLobby(page) {
  await openGameCenter(page);
  await page.locator('#joinGameSessionButton').waitFor({ state: 'visible', timeout: TIMEOUT });
  await page.locator('#joinGameSessionButton').click();
}

async function getGameStatus(page) {
  return (await page.locator('#gameSessionStatus').innerText().catch(() => '')).trim();
}

async function readyCountOnPage(page) {
  return page.locator('#gamePlayersList .game-session-member-state').evaluateAll((nodes) =>
    nodes.map((node) => (node.textContent || '').trim())
      .filter((state) => /Hazır/.test(state) && !/bekliyor/i.test(state)).length
  );
}

async function waitForReadyCount(observerPage, expectedCount) {
  await observerPage.waitForFunction((expected) => {
    const states = Array.from(document.querySelectorAll('#gamePlayersList .game-session-member-state'))
      .map((node) => (node.textContent || '').trim());
    const count = states.filter((state) => /Hazır/.test(state) && !/bekliyor/i.test(state)).length;
    return count >= expected;
  }, expectedCount, { timeout: TIMEOUT });
}

async function clickReadyIfNeeded(page, observerPage = page, expectedReadyCount = null) {
  const button = page.locator('#readyGameSessionButton');
  await button.waitFor({ state: 'visible', timeout: TIMEOUT });
  if (!(await button.innerText()).includes('✓')) {
    await button.click();
    await page.waitForFunction(() => (document.querySelector('#readyGameSessionButton')?.textContent || '').includes('✓'), null, { timeout: TIMEOUT });
  }
  if (Number.isInteger(expectedReadyCount)) await waitForReadyCount(observerPage, expectedReadyCount);
}

async function clickUnreadyIfNeeded(page, observerPage = page, expectedReadyCount = null) {
  const button = page.locator('#readyGameSessionButton');
  await button.waitFor({ state: 'visible', timeout: TIMEOUT });
  if ((await button.innerText()).includes('✓')) {
    await button.click();
    await page.waitForFunction(() => !(document.querySelector('#readyGameSessionButton')?.textContent || '').includes('✓'), null, { timeout: TIMEOUT });
  }
  if (Number.isInteger(expectedReadyCount)) {
    await observerPage.waitForFunction((expected) => {
      const states = Array.from(document.querySelectorAll('#gamePlayersList .game-session-member-state'))
        .map((node) => (node.textContent || '').trim());
      const count = states.filter((state) => /Hazır/.test(state) && !/bekliyor/i.test(state)).length;
      return count <= expected;
    }, expectedReadyCount, { timeout: TIMEOUT });
  }
}

async function readyPlayersSequentially(pages, observerPage = pages[0]) {
  let expected = await readyCountOnPage(observerPage);
  for (const page of pages) {
    const button = page.locator('#readyGameSessionButton');
    await button.waitFor({ state: 'visible', timeout: TIMEOUT });
    if (!(await button.innerText()).includes('✓')) {
      expected += 1;
      await clickReadyIfNeeded(page, observerPage, expected);
    }
  }
}

async function clearGameSessionAsHost(page) {
  await openGameCenter(page).catch(() => {});
  if (await page.locator('#closeGameSessionButton').isVisible().catch(() => false)) {
    page.once('dialog', (dialog) => dialog.accept());
    await page.locator('#closeGameSessionButton').click();
    await page.locator('#gameCenterEmptyState').waitFor({ state: 'visible', timeout: TIMEOUT }).catch(() => {});
    closedGameSessions.push('QA game session');
  }
}

async function clearGameSessionFromAnyHost(pages) {
  for (let i = 0; i < pages.length; i += 1) {
    const page = pages[i];
    await openGameCenter(page).catch(() => {});
    if (!(await page.locator('#closeGameSessionButton').isVisible().catch(() => false))) continue;
    page.once('dialog', (dialog) => dialog.accept());
    await page.locator('#closeGameSessionButton').click();
    await page.locator('#gameCenterEmptyState').waitFor({ state: 'visible', timeout: TIMEOUT }).catch(() => {});
    closedGameSessions.push(`QA game session closed by QA_USER_${i + 1}`);
    return true;
  }
  return false;
}

async function playUnoMatch(pages) {
  const maxActions = Math.max(40, Math.min(400, Number(process.env.CACA_QA_UNO_MAX_ACTIONS || 240)));
  let actions = 0;
  let hadPlayableCard = false;
  let hadDraw = false;
  let hadWild = false;
  let reconnectPassed = false;

  // The hand area is a single local-player UI; opponent rows expose counts, not card buttons.
  for (const page of pages) {
    await page.locator('.uno-overlay').waitFor({ state: 'visible', timeout: TIMEOUT });
    await page.locator('.uno-overlay [data-role="hand-count"]').waitFor({ state: 'visible', timeout: TIMEOUT });
  }
  const initialHands = await Promise.all(pages.map((page) => page.locator('.uno-overlay .uno-hand button.uno-card').count()));
  if (initialHands.some((n) => n < 1)) throw new Error('At least one local UNO hand did not render its private cards.');

  // Verify only the current player's visible hand has enabled card actions.
  const turnOwner = await findUnoTurnOwner(pages);
  if (turnOwner >= 0) {
    const disabledCheck = await Promise.all(pages.map(async (page, index) => {
      if (index === turnOwner) return true;
      const total = await page.locator('.uno-overlay .uno-hand button.uno-card').count();
      const enabled = await page.locator('.uno-overlay .uno-hand button.uno-card:not([disabled])').count();
      return total === 0 || enabled === 0;
    }));
    if (!disabledCheck.every(Boolean)) throw new Error('A non-current UNO player had an enabled card button.');
  }
  record('uno.rules-private-hands', 'passed', 'Each player saw only their own local hand; opponent rows showed card counts, and non-current players had no enabled card actions.');

  // Reconnect one player during a live match, then reopen their table from the room UI.
  try {
    const reconnectPage = pages[4];
    await reconnectPage.reload({ waitUntil: 'domcontentloaded', timeout: TIMEOUT });
    await reconnectPage.locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await reconnectPage.locator('#roomsList').getByText(/QA-/).first().click();
    await reconnectPage.locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await openGameCenter(reconnectPage);
    await reconnectPage.locator('#openGameMatchButton').waitFor({ state: 'visible', timeout: TIMEOUT });
    await reconnectPage.locator('#openGameMatchButton').click();
    await reconnectPage.locator('.uno-overlay').waitFor({ state: 'visible', timeout: TIMEOUT });
    await reconnectPage.locator('.uno-overlay [data-role="turn"]').waitFor({ state: 'visible', timeout: TIMEOUT });
    reconnectPassed = true;
    record('uno.reconnect-results', 'partial', 'A live-match refresh/reconnect succeeded; winner/results/next-round lifecycle is evaluated separately after the match ends.');
  } catch (error) {
    record('uno.reconnect-results', 'partial', `Live match refresh/reconnect did not complete: ${error.message}; results and next-round handling remain untested.`);
  }

  let resultSeen = false;
  let noProgressRounds = 0;
  for (let step = 0; step < maxActions; step += 1) {
    // Catch a pending UNO call from another player when the client presents the +2 action.
    let caught = false;
    for (const page of pages) {
      const catchButton = page.locator('.uno-overlay [data-action="catch"]');
      if (await catchButton.isVisible().catch(() => false) && await catchButton.isEnabled().catch(() => false)) {
        await catchButton.click().catch(() => {});
        caught = true;
        actions += 1;
        await page.waitForTimeout(350);
        break;
      }
    }
    if (caught) continue;

    const hasResult = await Promise.all(pages.map((page) => page.locator('.uno-overlay [data-role="result"]').isVisible().catch(() => false)));
    if (hasResult.some(Boolean)) { resultSeen = true; break; }

    const current = await findUnoTurnOwner(pages);
    if (current < 0) {
      noProgressRounds += 1;
      if (noProgressRounds > 40) break;
      await pages[0].waitForTimeout(250);
      continue;
    }
    noProgressRounds = 0;
    const page = pages[current];
    const playable = page.locator('.uno-overlay .uno-hand button.uno-card:not([disabled])');
    const playableCount = await playable.count();

    if (playableCount > 0) {
      hadPlayableCard = true;
      await playable.first().click();
      const colorModal = page.locator('.uno-overlay [data-role="color-modal"]');
      if (await colorModal.isVisible().catch(() => false)) {
        hadWild = true;
        await colorModal.locator('button[data-color="green"]').click();
      }
      await page.waitForTimeout(350);
      const unoButton = page.locator('.uno-overlay [data-action="uno"]');
      if (await unoButton.isVisible().catch(() => false) && await unoButton.isEnabled().catch(() => false)) {
        await unoButton.click().catch(() => {});
      }
      actions += 1;
    } else {
      await page.locator('.uno-overlay .uno-draw-pile').click();
      hadDraw = true;
      await page.waitForTimeout(450);
      const endTurn = page.locator('.uno-overlay [data-action="end-turn"]');
      if (await endTurn.isVisible().catch(() => false) && await endTurn.isEnabled().catch(() => false)) {
        await endTurn.click();
      } else {
        const drawnPlayable = page.locator('.uno-overlay .uno-hand button.uno-card:not([disabled])');
        if (await drawnPlayable.count()) {
          await drawnPlayable.first().click();
          const modal = page.locator('.uno-overlay [data-role="color-modal"]');
          if (await modal.isVisible().catch(() => false)) {
            hadWild = true;
            await modal.locator('button[data-color="green"]').click();
          }
          await page.waitForTimeout(300);
          const uno = page.locator('.uno-overlay [data-action="uno"]');
          if (await uno.isVisible().catch(() => false) && await uno.isEnabled().catch(() => false)) await uno.click().catch(() => {});
        }
      }
      actions += 1;
    }

    if (step % 12 === 0) {
      const statusTexts = await Promise.all(pages.map(async (p) => p.locator('.uno-overlay [data-role="status"]').innerText().catch(() => '')));
      if (statusTexts.some((v) => /Maç tamamlandı/i.test(v))) { resultSeen = true; break; }
    }
  }

  if (!resultSeen) {
    const finalChecks = await Promise.all(pages.map((page) => page.locator('.uno-overlay [data-role="result"]').isVisible().catch(() => false)));
    resultSeen = finalChecks.some(Boolean);
  }
  if (resultSeen) {
    record('uno.match', 'passed', `The automated five-player UNO table reached its results screen after ${actions} player actions.`);
    if (hadPlayableCard && hadDraw) {
      record('uno.rules-private-hands', 'passed', `Private-hand visibility and turn gating were verified; the match exercised valid card play and draw (${actions} actions).${hadWild ? ' A wild-card color selection was also exercised.' : ' No wild card was drawn during this run.'}`);
    }
    record('uno.reconnect-results', reconnectPassed ? 'passed' : 'partial', reconnectPassed ? 'A player reconnected during the live match and the five-player match subsequently reached results.' : 'The match reached results; live reconnect was not verified successfully in this run.');
  } else {
    record('uno.match', 'partial', `The match started and accepted ${actions} UI actions, but did not reach the results screen within the ${maxActions}-action safety limit.`);
    record('uno.reconnect-results', 'partial', 'Live reconnect may have worked, but winner detection/results/next round were not observed before the action limit.');
  }

  // Give the CACA game UI time to return to the persistent lobby after its results timer.
  if (resultSeen) {
    await pages[0].waitForTimeout(5500);
    await openGameCenter(pages[0]).catch(() => {});
    const status = await getGameStatus(pages[0]);
    if (/Maç sonuçlandı|Lobi açık|Geri sayım/i.test(status)) {
      // The visible state itself confirms that the result route returned to the room game center.
    }
  }
}

async function findUnoTurnOwner(pages) {
  for (let i = 0; i < pages.length; i += 1) {
    const text = await pages[i].locator('.uno-overlay [data-role="turn"]').innerText().catch(() => '');
    if (/SIRA SENDE/i.test(text)) return i;
  }
  return -1;
}

async function testUnoLobby(pages) {
  const owner = pages[0];
  // First prove host transfer in a small disposable lobby before creating the full match lobby.
  await runCase('lobby.leave-transfer', owner, async () => {
    await selectCatalogGame(owner, 'uno');
    await joinSharedGameLobby(pages[1]);
    await owner.waitForFunction(() => Number.parseInt(document.querySelector('#gamePlayersCount')?.textContent || '', 10) === 2, null, { timeout: TIMEOUT });
    await owner.locator('#leaveGameSessionButton').click();
    await pages[1].waitForFunction((name) => (document.querySelector('#gameSessionHost')?.textContent || '').includes(name), credentials[1].username, { timeout: TIMEOUT });
    if (!(await pages[1].locator('#closeGameSessionButton').isVisible())) throw new Error('The new host did not receive lobby management controls.');
    pages[1].once('dialog', (dialog) => dialog.accept());
    await pages[1].locator('#closeGameSessionButton').click();
    await pages[1].locator('#gameCenterEmptyState').waitFor({ state: 'visible', timeout: TIMEOUT });
    closedGameSessions.push('UNO host-transfer lobby');
    return 'The first owner left a two-player lobby; QA_USER_2 became host and closed the test lobby through the normal UI.';
  });
  // If any host-transfer step failed halfway through, only the current lobby host can clean it up.
  await clearGameSessionFromAnyHost(pages).catch(() => {});

  await runCase('lobby.uno-create-join', owner, async () => {
    await selectCatalogGame(owner, 'uno');
    for (let i = 1; i < 5; i += 1) {
      await joinSharedGameLobby(pages[i]);
      await owner.waitForFunction((expected) => {
        const count = Number.parseInt(document.querySelector('#gamePlayersCount')?.textContent || '', 10);
        return count === expected;
      }, i + 1, { timeout: TIMEOUT });
    }
    await owner.waitForFunction(() => document.querySelector('#gamePlayersCount')?.textContent?.trim() === '5/10', null, { timeout: TIMEOUT });
    return 'The owner created a shared UNO lobby and all five QA accounts joined through the UI.';
  });

  await runCase('lobby.refresh', pages[4], async () => {
    await pages[4].reload({ waitUntil: 'domcontentloaded', timeout: TIMEOUT });
    await pages[4].locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await pages[4].locator('#roomsList').getByText(primaryQaRoomName, { exact: true }).click();
    await pages[4].locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
    await openGameCenter(pages[4]);
    await pages[4].waitForFunction(() => Number.parseInt(document.querySelector('#gamePlayersCount')?.textContent || '', 10) === 5, null, { timeout: TIMEOUT });
    const renderedPlayers = await pages[4].locator('#gamePlayersList .game-session-member').count();
    if (renderedPlayers !== 5) throw new Error(`Lobby refresh showed ${renderedPlayers} player rows instead of five.`);
    return 'QA_USER_5 refreshed while the UNO lobby was still open; the room UI restored exactly five player rows with no missing or duplicate member.';
  });

  await runCase('lobby.uno-ready', owner, async () => {
    // Explicit ready -> unready transition. Wait for the owner listener to
    // display each committed state before the same account toggles again.
    const togglePage = pages[4];
    await clickUnreadyIfNeeded(togglePage, owner, 0);
    await clickReadyIfNeeded(togglePage, owner, 1);
    await clickUnreadyIfNeeded(togglePage, owner, 0);
    // Ready the four other members one at a time; the owner observes each write.
    for (let i = 1; i < 5; i += 1) await clickReadyIfNeeded(pages[i], owner, i);
    await clickReadyIfNeeded(owner, owner, 5);
    await owner.waitForFunction(() => /Geri sayım başladı|Maç devam ediyor/i.test(document.querySelector('#gameSessionStatus')?.textContent || ''), null, { timeout: TIMEOUT });
    return 'The same member toggled ready and unready; all five QA players then became ready and the countdown began.';
  });

  const countdownInitial = await getGameStatus(owner);
  if (/Maç devam ediyor/i.test(countdownInitial)) {
    record('lobby.countdown', 'partial', 'The three-second countdown completed before a cancellation action could be sent; match start was observed but cancellation was not verified.');
  } else await runCase('lobby.countdown', owner, async () => {
    // The countdown is three seconds. Cancel it immediately with one previously-ready member.
    const cancelPage = pages[1];
    await clickUnreadyIfNeeded(cancelPage, owner, 4);
    await owner.waitForFunction(() => /Lobi açık/i.test(document.querySelector('#gameSessionStatus')?.textContent || ''), null, { timeout: 6000 });
    // Ready every player again to proceed into the match.
    await readyPlayersSequentially(pages, owner);
    await owner.waitForFunction(() => /Maç devam ediyor/i.test(document.querySelector('#gameSessionStatus')?.textContent || ''), null, { timeout: 15000 });
    return 'A player cancelled the three-second countdown by toggling readiness; the group then readied again and the match started.';
  });

  // If countdown cancellation could not be proven, still wait for a normal match start.
  if (!['passed', 'partial'].includes(results.get('lobby.countdown').status)) {
    try {
      await readyPlayersSequentially(pages, owner);
      await owner.waitForFunction(() => /Maç devam ediyor/i.test(document.querySelector('#gameSessionStatus')?.textContent || ''), null, { timeout: 15000 });
    } catch { /* result remains accurately recorded */ }
  }

  if (/Maç devam ediyor/i.test(await getGameStatus(owner))) {
    try {
      for (const page of pages) {
        await openGameCenter(page);
        await page.locator('#openGameMatchButton').waitFor({ state: 'visible', timeout: TIMEOUT });
        await page.locator('#openGameMatchButton').click();
        await page.locator('.uno-overlay').waitFor({ state: 'visible', timeout: TIMEOUT });
      }
      // The full game runner records detailed match/private-hand/reconnect outcomes itself.
      await playUnoMatch(pages);
    } catch (error) {
      record('uno.match', isNetworkBlocked(error) ? 'blocked' : 'partial', `UNO match table automation was interrupted: ${error.message}`);
      if (results.get('uno.rules-private-hands').status === 'pending') record('uno.rules-private-hands', 'blocked', 'UNO table did not initialize far enough to inspect private hands.');
      if (results.get('uno.reconnect-results').status === 'pending') record('uno.reconnect-results', 'blocked', 'UNO table did not initialize far enough to test reconnect/results.');
    }
  } else {
    for (const id of ['uno.match', 'uno.rules-private-hands', 'uno.reconnect-results']) {
      if (results.get(id).status === 'pending') record(id, 'blocked', 'The shared UNO lobby did not reach the playing state; the match UI could not be opened.');
    }
    record('lobby.refresh', 'blocked', 'No active UNO match existed to test refresh/reconnect behavior.');
  }

  // Close the game lobby created by this run using the host UI when it is available.
  try { await clearGameSessionAsHost(owner); } catch (error) { browserLogs.get('QA_USER_1')?.push({ at: new Date().toISOString(), kind: 'game-cleanup-error', message: scrub(error.message) }); }
}

async function runVampirRoundActions(pages, phaseBudgetMs = 70000) {
  const phaseAtStart = await pages[0].locator('.vampir-overlay [data-role="phase"]').innerText().catch(() => '');
  const deadline = Date.now() + phaseBudgetMs;
  let sentNight = false;
  let sentDayChat = false;
  let sentVotes = false;
  while (Date.now() < deadline) {
    let phase = '';
    for (const page of pages) {
      phase = await page.locator('.vampir-overlay [data-role="phase"]').innerText().catch(() => '');
      if (phase) break;
    }
    if (/GÜNDÜZ/i.test(phase) && !sentDayChat) {
      let page = pages[0];
      for (const candidate of pages) {
        if (await candidate.locator('.vampir-overlay [data-role="chat-input"]').isEnabled().catch(() => false)) { page = candidate; break; }
      }
      const input = page.locator('.vampir-overlay [data-role="chat-input"]');
      if (await input.isEnabled().catch(() => false)) {
        const message = `CACA QA discussion ${RUN_ID}`;
        await input.fill(message);
        await page.locator('.vampir-overlay [data-action="send-chat"]').click();
        await page.waitForFunction((value) => (document.querySelector('.vampir-overlay [data-role="chat-messages"]')?.innerText || '').includes(value), message, { timeout: 10000 }).catch(() => {});
        sentDayChat = true;
      }
    }
    if (/GECE/i.test(phase) && !sentNight) {
      for (const page of pages) {
        const ownRole = (await page.locator('.vampir-overlay [data-role="role-name"]').innerText().catch(() => '')).trim();
        if (ownRole === 'Vampir' || ownRole === 'Doktor') {
          const target = page.locator('.vampir-overlay .vampir-target-button').first();
          if (await target.isVisible().catch(() => false)) await target.click();
        }
      }
      sentNight = true;
    }
    if (/OYLAMA/i.test(phase) && !sentVotes) {
      for (const page of pages) {
        const targets = page.locator('.vampir-overlay .vampir-target-button');
        if (await targets.count()) await targets.first().click();
      }
      sentVotes = true;
    }
    if (sentNight && sentDayChat && sentVotes) break;
    await pages[0].waitForTimeout(500);
  }
  return { phaseAtStart, sentNight, sentDayChat, sentVotes };
}

async function testVampirRealPlayers(pages) {
  const owner = pages[0];
  await runCase('vampir.real-players', owner, async () => {
    await selectCatalogGame(owner, 'vampir-koylu');
    for (let i = 1; i < 5; i += 1) {
      await joinSharedGameLobby(pages[i]);
      await owner.waitForFunction((expected) => {
        const count = Number.parseInt(document.querySelector('#gamePlayersCount')?.textContent || '', 10);
        return count === expected;
      }, i + 1, { timeout: TIMEOUT });
    }
    await owner.waitForFunction(() => document.querySelector('#gamePlayersCount')?.textContent?.trim() === '5/12', null, { timeout: TIMEOUT });
    await readyPlayersSequentially(pages, owner);
    await owner.waitForFunction(() => /Maç devam ediyor/i.test(document.querySelector('#gameSessionStatus')?.textContent || ''), null, { timeout: 15000 });
    for (const page of pages) {
      await openGameCenter(page);
      await page.locator('#openGameMatchButton').waitFor({ state: 'visible', timeout: TIMEOUT });
      await page.locator('#openGameMatchButton').click();
      await page.locator('.vampir-overlay').waitFor({ state: 'visible', timeout: TIMEOUT });
      await page.waitForFunction(() => !/Rol bekleniyor/i.test(document.querySelector('.vampir-overlay [data-role="role-name"]')?.textContent || ''), null, { timeout: TIMEOUT });
    }
    const roleNames = await Promise.all(pages.map((page) => page.locator('.vampir-overlay [data-role="role-name"]').innerText()));
    for (const page of pages) {
      const publicList = await page.locator('.vampir-overlay .vampir-player-list').innerText();
      if (/\bVampir\b|\bDoktor\b|\bKöylü\b/i.test(publicList)) {
        throw new Error('A private role label appeared in the public Vampir Köylü player list.');
      }
    }
    const counts = {
      vampir: roleNames.filter((x) => x.trim() === 'Vampir').length,
      doktor: roleNames.filter((x) => x.trim() === 'Doktor').length,
      koylu: roleNames.filter((x) => x.trim() === 'Köylü').length
    };
    if (counts.vampir !== 1 || counts.doktor !== 1 || counts.koylu !== 3) throw new Error(`Five-human role assignment was unexpected: ${JSON.stringify(counts)}.`);
    record('vampir.roles-private', 'passed', 'Five real clients each displayed only their own role card; no role labels appeared in the public player list.');
    if (results.get('uno.rules-private-hands').status === 'passed') {
      record('security.private-game-data', 'passed', 'UNO card controls were local to each signed-in hand and Vampir Köylü role cards showed only the signed-in player’s role.');
    } else {
      record('security.private-game-data', 'partial', 'Vampir Köylü private-role UI was checked; UNO private-hand verification was not completed.');
    }
    return 'Five real QA accounts started a Vampir Köylü match; roles were assigned as one Vampir, one Doktor and three Köylü.';
  });

  const allVampirOverlaysVisible = (await Promise.all(pages.map((page) => page.locator('.vampir-overlay').isVisible().catch(() => false)))).every(Boolean);
  if (allVampirOverlaysVisible) {
    await runCase('vampir.phases-votes', owner, async () => {
      const actions = await runVampirRoundActions(pages, 95000);
      const phaseTexts = await Promise.all(pages.map((page) => page.locator('.vampir-overlay [data-role="phase"]').innerText().catch(() => '')));
      if (!actions.sentNight) throw new Error('No human Vampir/Doktor night action was submitted in the observed phase window.');
      if (!actions.sentDayChat) throw new Error('A living human did not send a daytime discussion message within the phase window.');
      if (!actions.sentVotes) throw new Error('The voting phase did not arrive or human votes were not submitted within the phase window.');
      return `Night action submitted=${actions.sentNight}; discussion chat sent=${actions.sentDayChat}; votes submitted=${actions.sentVotes}; current phase=${phaseTexts[0] || 'unknown'}.`;
    });

    await runCase('vampir.reconnect', pages[4], async () => {
      await pages[4].reload({ waitUntil: 'domcontentloaded', timeout: TIMEOUT });
      await pages[4].locator('#appView').waitFor({ state: 'visible', timeout: TIMEOUT });
      await pages[4].locator('#roomsList').getByText(/QA-/).first().click();
      await pages[4].locator('#roomView').waitFor({ state: 'visible', timeout: TIMEOUT });
      await openGameCenter(pages[4]);
      if (await pages[4].locator('#openGameMatchButton').isVisible().catch(() => false)) {
        await pages[4].locator('#openGameMatchButton').click();
        await pages[4].locator('.vampir-overlay').waitFor({ state: 'visible', timeout: TIMEOUT });
        await pages[4].waitForFunction(() => !/Rol bekleniyor/i.test(document.querySelector('.vampir-overlay [data-role="role-name"]')?.textContent || ''), null, { timeout: TIMEOUT });
      }
      return 'QA_USER_5 refreshed during the real-player Vampir Köylü round and reopened the game UI with their private role restored.';
    });
    record('vampir.victory-results', 'partial', 'The real-player match and opening phase actions were exercised; both victory conditions and automatic result return were not forced to completion in this smoke run.');
  } else {
    for (const id of ['vampir.roles-private', 'vampir.phases-votes', 'vampir.reconnect', 'vampir.victory-results', 'security.private-game-data']) {
      if (results.get(id).status === 'pending') record(id, 'blocked', 'The real-player Vampir Köylü match did not start, so private-role and phase tests could not run.');
    }
  }

  // Leave only this run-created match and close its persistent lobby where the host UI allows it.
  for (const page of pages) {
    const close = page.locator('.vampir-overlay [data-action="close"]');
    if (await close.isVisible().catch(() => false)) {
      page.once('dialog', (dialog) => dialog.accept());
      await close.click().catch(() => {});
    }
  }
  await owner.waitForTimeout(1000);
  await clearGameSessionAsHost(owner).catch(() => {});
}

async function testVampirBots(pages) {
  const owner = pages[0];
  const targets = [5, 8, 12];
  let settingsPermissionObserved = false;
  let anyBotActionObserved = false;

  for (const targetCount of targets) {
    const id = `bots.target-${targetCount}`;
    await runCase(id, owner, async () => {
      await selectCatalogGame(owner, 'vampir-koylu');
      await owner.locator('#gameLobbySettingsButton').waitFor({ state: 'visible', timeout: TIMEOUT });
      await owner.locator('#gameLobbySettingsButton').click();
      await owner.locator('#gameLobbySettingsPanel').waitFor({ state: 'visible', timeout: TIMEOUT });
      await owner.locator('#gameBotFillToggle').check();
      await owner.locator('#gameBotTargetCount').selectOption(String(targetCount));
      await owner.waitForFunction((n) => (document.querySelector('#gameBotSettingsPreview')?.textContent || '').includes(`${n - 1} bot`), targetCount, { timeout: TIMEOUT });
      await owner.locator('#saveGameLobbySettingsButton').click();
      await owner.locator('#gameLobbySettingsPanel').waitFor({ state: 'hidden', timeout: TIMEOUT });

      // Normal members must not be able to open host-only bot settings.
      await openGameCenter(pages[1]);
      const hiddenForMember = !(await pages[1].locator('#gameLobbySettingsButton').isVisible());
      await closeRoomDialogs(pages[1]);
      settingsPermissionObserved = hiddenForMember;

      await clickReadyIfNeeded(owner, owner, 1);
      await owner.waitForFunction(() => /Maç devam ediyor/i.test(document.querySelector('#gameSessionStatus')?.textContent || ''), null, { timeout: 15000 });
      await openGameCenter(owner);
      await owner.locator('#openGameMatchButton').waitFor({ state: 'visible', timeout: TIMEOUT });
      await owner.locator('#openGameMatchButton').click();
      await owner.locator('.vampir-overlay').waitFor({ state: 'visible', timeout: TIMEOUT });
      await owner.waitForFunction((n) => document.querySelectorAll('.vampir-overlay .vampir-player-list .vampir-player').length === n, targetCount, { timeout: TIMEOUT });
      const playerCount = await owner.locator('.vampir-overlay .vampir-player-list .vampir-player').count();
      const botLabels = await owner.locator('.vampir-overlay .vampir-player-list').innerText();
      const botCount = (botLabels.match(/· Bot/g) || []).length;
      if (playerCount !== targetCount || botCount !== targetCount - 1) throw new Error(`Expected one real user plus ${targetCount - 1} bots; rendered ${playerCount} participants and ${botCount} bot labels.`);
      const realLobbyCount = (await owner.locator('#gamePlayersCount').innerText()).trim();
      if (Number.parseInt(realLobbyCount, 10) !== 1) throw new Error(`Bots appeared as real lobby members; expected one real player, saw ${realLobbyCount}.`);
      const ownRole = (await owner.locator('.vampir-overlay [data-role="role-name"]').innerText()).trim();
      if (!['Vampir', 'Doktor', 'Köylü'].includes(ownRole)) throw new Error(`Private role was not assigned; UI displayed ${ownRole}.`);

      // If the human holds a night-action role, submit one valid target and observe the server state.
      const actionButton = owner.locator('.vampir-overlay .vampir-target-button').first();
      if ((ownRole === 'Vampir' || ownRole === 'Doktor') && await actionButton.isVisible().catch(() => false)) {
        await actionButton.click();
        await owner.waitForTimeout(1200);
      }
      await owner.waitForTimeout(2500);
      const discussion = await owner.locator('.vampir-overlay [data-role="chat-messages"]').innerText().catch(() => '');
      if (/Bot/.test(discussion)) anyBotActionObserved = true;

      // Leave only this bot-filled QA match through the in-game exit confirmation.
      owner.once('dialog', (dialog) => dialog.accept());
      await owner.locator('.vampir-overlay [data-action="close"]').click();
      await owner.locator('.vampir-overlay').waitFor({ state: 'hidden', timeout: 10000 }).catch(() => {});
      return `Target ${targetCount}: UI displayed ${playerCount} participants (${botCount} bots + one real QA user); lobby player count stayed at one and role=${ownRole}.`;
    });
    await owner.waitForTimeout(800);
    await clearGameSessionAsHost(owner).catch(() => {});
  }

  if (settingsPermissionObserved) record('bots.permissions', 'passed', 'Host bot settings were visible to QA_USER_1 and hidden from a normal QA member.');
  else record('bots.permissions', 'partial', 'The host-only bot settings visibility test could not be confirmed for every target run.');
  if (anyBotActionObserved) record('bots.actions', 'partial', 'At least one bot discussion/action was observed; full game completion for all bot counts was not forced in this run.');
  else record('bots.actions', 'partial', 'Bot-filled lobbies started and participant counts were checked; a complete bot-driven victory sequence was not observed.');
}

async function cleanupRun(pages) {
  if (!pages?.length) return;
  const owner = pages[0];
  // Close only QA game overlays/lobbies created by this run.
  for (const page of pages) {
    for (const selector of ['.uno-overlay [data-action="close"]', '.vampir-overlay [data-action="close"]']) {
      const close = page.locator(selector);
      if (await close.isVisible().catch(() => false)) {
        page.once('dialog', (dialog) => dialog.accept());
        await close.click({ timeout: 4000 }).catch(() => {});
        await page.waitForTimeout(400);
      }
    }
  }
  await clearGameSessionFromAnyHost(pages).catch(() => {});

  // Delete only the primary QA room created by this run, through its normal owner UI.
  if (!primaryQaRoomName) return;
  try {
    if (!(await owner.locator('#roomView').isVisible().catch(() => false)) ||
        (await owner.locator('#activeRoomName').innerText().catch(() => '')).trim() !== primaryQaRoomName) {
      await closeRoomDialogs(owner);
      const roomRow = owner.locator('#roomsList').getByText(primaryQaRoomName, { exact: true });
      if (await roomRow.count()) {
        await roomRow.click();
        await owner.locator('#roomView').waitFor({ state: 'visible', timeout: 10000 });
      }
    }
    if ((await owner.locator('#activeRoomName').innerText().catch(() => '')).trim() === primaryQaRoomName) {
      await closeRoomDialogs(owner);
      owner.once('dialog', (dialog) => dialog.accept());
      await owner.locator('#leaveRoomButton').click();
      await owner.locator('#dashboardView').waitFor({ state: 'visible', timeout: 15000 });
      cleanedUpRoomNames.push(primaryQaRoomName);
    }
  } catch (error) {
    browserLogs.get('QA_USER_1')?.push({ at: new Date().toISOString(), kind: 'room-cleanup-error', message: scrub(error.message) });
  }
}

async function run() {
  await fs.mkdir(ARTIFACTS, { recursive: true });
  await loadCredentials();

  const metadata = {
    runId: RUN_ID,
    startedAt: new Date().toISOString(),
    website: BASE_URL,
    workerHealth: HEALTH_URL,
    sourceRepository: 'https://github.com/potatorman/caca',
    registrationModel: 'username + password only; no email or verification steps',
    credentialsStoredAt: 'private/credentials.json (excluded from reports and Git)',
    accountsRequested: 5,
    accountAliases: credentials.map((a) => a.alias),
    browser: null,
    notes: []
  };

  let browserSiteError = null;
  try {
    browser = await chromium.launch({ headless: !HEADFUL, args: ['--no-sandbox'] });
    metadata.browser = `Playwright Chromium (${HEADFUL ? 'headed' : 'headless'})`;
  } catch (error) {
    metadata.browser = 'launch failed';
    metadata.notes.push(`Chromium launch failed: ${scrub(error.message)}`);
    record('site.home', 'blocked', 'Browser could not launch, so the deployed site could not be opened.');
    record('worker.health', 'blocked', 'The Worker health check is not reached because browser setup failed; retry after installing Playwright Chromium.');
    blockPending('Browser launch failed; no production UI interactions were performed.');
    await finish(metadata);
    return;
  }

  // Check Worker health separately so a site outage does not hide a healthy Worker (or vice versa).
  let api;
  try {
    api = await request.newContext({ timeout: TIMEOUT });
    const response = await api.get(HEALTH_URL);
    const payload = await response.json().catch(() => ({}));
    if (response.status() === 200 && payload.ok === true && payload.service === 'caca-uno') {
      record('worker.health', 'passed', `Worker responded with HTTP 200; service=${payload.service}; version=${payload.version ?? 'not returned'}.`);
    } else {
      record('worker.health', 'failed', `Worker health response was HTTP ${response.status()} with an unexpected payload shape.`);
    }
  } catch (error) {
    record('worker.health', isNetworkBlocked(error) ? 'blocked' : 'failed', `Worker health endpoint could not be verified from this environment: ${error.message}`);
    metadata.notes.push(`Worker health check: ${scrub(error.message)}`);
  } finally {
    await api?.dispose().catch(() => {});
  }

  // Open the actual deployed CACA site before touching any account.
  const probeContext = await browser.newContext();
  try {
    const probePage = await openPage(probeContext, 'SITE_PROBE');
    await probePage.locator('#loginForm').waitFor({ state: 'visible', timeout: TIMEOUT });
    record('site.home', 'passed', 'The deployed CACA login UI loaded and exposed the username/password form.');
  } catch (error) {
    browserSiteError = error;
    record('site.home', isNetworkBlocked(error) ? 'blocked' : 'failed', `The deployed CACA UI could not be opened: ${error.message}`);
    metadata.notes.push(`Website navigation: ${scrub(error.message)}`);
  } finally {
    await probeContext.close().catch(() => {});
  }

  if (browserSiteError) {
    const reason = isNetworkBlocked(browserSiteError)
      ? 'Execution environment blocked outbound access to the production host. No registration or application action was attempted; this is an environment block, not a CACA pass/fail result.'
      : 'Production site was unavailable at the UI preflight stage. No account or application test was attempted.';
    blockPending(reason);
    await finish(metadata);
    await browser.close();
    return;
  }

  try {
    // Create five fully separate browser contexts; no shared cookies/local storage.
    for (let i = 0; i < 5; i += 1) {
      const context = await browser.newContext();
      contexts.push(context);
      const page = await openPage(context, credentials[i].alias);
      if ((await page.locator('#registerUsername').count()) === 0) throw new Error('Registration username field missing.');
      try {
        const detail = await registerOrLogin(page, credentials[i]);
        record(`accounts.register.${i + 1}`, 'passed', `${credentials[i].alias}: ${detail}`);
      } catch (error) {
        record(`accounts.register.${i + 1}`, 'failed', `${credentials[i].alias}: ${error.message}`);
        const screenshot = await safeScreenshot(page, `register-${i + 1}-failure`);
        if (screenshot) results.get(`accounts.register.${i + 1}`).evidence.push(screenshot);
      }
    }

    // Keep account UI sessions independent; negative tests use a sixth, disposable context.
    try {
      await testAuthNegativeCases();
    } catch (error) {
      for (const id of ['accounts.duplicate', 'accounts.short-password', 'accounts.invalid-login']) {
        if (results.get(id).status === 'pending') record(id, isNetworkBlocked(error) ? 'blocked' : 'failed', error.message);
      }
    }

    const pages = contexts.map((context) => context.pages()[0]);
    const allAuthenticated = pages.every(Boolean) && (await Promise.all(pages.map((page) => page.locator('#appView').isVisible().catch(() => false)))).every(Boolean);
    if (allAuthenticated) {
      try {
        await testAccountSessions(pages);
      } catch (error) {
        for (const id of ['accounts.concurrent', 'accounts.logout-login', 'accounts.refresh', 'accounts.reopen']) {
          if (results.get(id).status === 'pending') record(id, 'failed', error.message);
        }
      }

      try {
        await testRoomChatAndRoles(pages);
      } catch (error) {
        const screenshot = await safeScreenshot(pages[0], 'room-chat-role-failure');
        const evidence = screenshot ? [screenshot] : [];
        for (const id of ['rooms.create', 'rooms.join', 'rooms.members', 'chat.realtime', 'chat.turkish-emoji-long', 'chat.history-refresh', 'roles.promote-admin', 'roles.admin-permissions', 'roles.member-restrictions', 'roles.owner-only', 'roles.revoke-admin', 'pranks.shake', 'rooms.leave-rejoin']) {
          if (results.get(id).status === 'pending') record(id, 'failed', error.message, evidence);
        }
      }

      try {
        await testUnoLobby(pages);
      } catch (error) {
        const screenshot = await safeScreenshot(pages[0], 'uno-lobby-failure');
        const evidence = screenshot ? [screenshot] : [];
        for (const id of ['lobby.uno-create-join', 'lobby.uno-ready', 'lobby.leave-transfer', 'lobby.countdown', 'lobby.refresh', 'uno.match', 'uno.rules-private-hands', 'uno.reconnect-results']) {
          if (results.get(id).status === 'pending') record(id, 'failed', error.message, evidence);
        }
      }
      try {
        await testVampirRealPlayers(pages);
      } catch (error) {
        const screenshot = await safeScreenshot(pages[0], 'vampir-real-players-failure');
        const evidence = screenshot ? [screenshot] : [];
        for (const id of ['vampir.real-players', 'vampir.roles-private', 'vampir.phases-votes', 'vampir.victory-results', 'vampir.reconnect', 'security.private-game-data']) {
          if (results.get(id).status === 'pending') record(id, isNetworkBlocked(error) ? 'blocked' : 'partial', error.message, evidence);
        }
      }
      try {
        await testVampirBots(pages);
      } catch (error) {
        const screenshot = await safeScreenshot(pages[0], 'vampir-bots-failure');
        const evidence = screenshot ? [screenshot] : [];
        for (const id of ['bots.target-5', 'bots.target-8', 'bots.target-12', 'bots.permissions', 'bots.actions']) {
          if (results.get(id).status === 'pending') record(id, isNetworkBlocked(error) ? 'blocked' : 'partial', error.message, evidence);
        }
      }
      await cleanupRun(pages);
    } else {
      for (let i = 0; i < 5; i += 1) {
        if (results.get(`accounts.register.${i + 1}`).status === 'pending') record(`accounts.register.${i + 1}`, 'failed', 'Registration/login did not leave this QA account authenticated.');
      }
      for (const id of ['accounts.concurrent', 'accounts.logout-login', 'accounts.refresh', 'accounts.reopen']) {
        if (results.get(id).status === 'pending') record(id, 'blocked', 'At least one of the five independent QA accounts did not authenticate.');
      }
      blockPending('Dependent UI flows require all five QA accounts to authenticate successfully.');
    }
  } finally {
    await persistBrowserLogs();
    for (const context of contexts) await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }

  blockPending('Not executed in this runner pass. It remains untested and must not be treated as working.');
  await finish(metadata);
}

async function finish(metadata) {
  await persistBrowserLogs().catch(() => {});
  const endedAt = new Date().toISOString();
  const summary = counts();
  const reportData = {
    metadata: { ...metadata, endedAt },
    summary,
    tests: [...results.values()],
    cleanup: {
      qaAccountsCreated: credentials.filter((a) => a.created).length,
      qaAccountsRequested: 5,
      accountAliases: credentials.map((a) => a.alias),
      qaRoomsCreated: createdRoomNames,
      qaRoomsCleanedUp: [...new Set(cleanedUpRoomNames)],
      gameSessionsCreated: createdGameSessions,
      gameSessionsClosed: closedGameSessions,
      roomCleanup: createdRoomNames.length ? `${new Set(cleanedUpRoomNames).size} of ${new Set(createdRoomNames).size} QA rooms were deleted through the normal owner UI.` : 'No QA rooms were created.',
      credentialFile: 'private/credentials.json; excluded from report and Git',
      noPersonalAccountUsed: true
    }
  };
  await fs.writeFile(RESULTS_FILE, `${JSON.stringify(reportData, null, 2)}\n`, { mode: 0o600 });
  try { await fs.chmod(RESULTS_FILE, 0o600); } catch { /* Windows ACLs inherited from project folder. */ }

  const groups = new Map();
  for (const item of reportData.tests) {
    const category = item.id.split('.')[0].toUpperCase();
    if (!groups.has(category)) groups.set(category, []);
    groups.get(category).push(item);
  }
  let md = `# CACA QA Report\n\n`;
  md += `- Run: ${metadata.runId}\n- Started: ${metadata.startedAt}\n- Ended: ${endedAt}\n- Target: ${metadata.website}\n- Worker health: ${metadata.workerHealth}\n- Registration: username + password only; no email or verification workflow\n- Accounts: five independent QA aliases; credentials are stored only in the private local file and are not reproduced here\n\n`;
  md += `## Overall health\n\n`;
  md += `| Total | Passed | Failed | Partial | Blocked | Pending |\n|---:|---:|---:|---:|---:|---:|\n`;
  md += `| ${summary.total} | ${summary.passed} | ${summary.failed} | ${summary.partial} | ${summary.blocked} | ${summary.pending} |\n\n`;
  md += `**Assessment:** ${summary.failed > 0 ? 'At least one executed test failed.' : summary.passed > 0 ? 'Some tests were executed; see the individual results and untested items.' : 'No CACA application tests were completed in this run. Blocked or untested features are not considered working.'}\n\n`;
  md += `## 1. Working features\n\n`;
  const passed = reportData.tests.filter((x) => x.status === 'passed');
  md += passed.length ? passed.map((x) => `- **${x.name}** — ${x.details}`).join('\n') + '\n\n' : 'No CACA features were verified as working in this run.\n\n';
  md += `## 2. Partially buggy / unreliable features\n\n`;
  const partial = reportData.tests.filter((x) => x.status === 'partial');
  md += partial.length ? partial.map((x) => `- **${x.name}** — ${x.details}`).join('\n') + '\n\n' : 'No partial outcomes recorded.\n\n';
  md += `## 3. Broken / buggy features\n\n`;
  const failed = reportData.tests.filter((x) => x.status === 'failed');
  md += failed.length ? failed.map((x) => `- **${x.name}** — Severity: Not assigned; needs reproduction/triage. ${x.details}${x.evidence.length ? ` Evidence: ${x.evidence.join(', ')}` : ''}`).join('\n') + '\n\n' : 'No reproducible CACA application defect was confirmed in this run. Environment blocks are not classified as application bugs.\n\n';
  md += `## 4. Not tested / blocked\n\n`;
  const blocked = reportData.tests.filter((x) => x.status === 'blocked');
  md += blocked.length ? blocked.map((x) => `- **${x.name}** — ${x.details}`).join('\n') + '\n\n' : 'No blocked tests.\n\n';
  md += `## 5. Test totals and priorities\n\n`;
  md += `Totals: ${summary.total} total, ${summary.passed} passed, ${summary.failed} failed, ${summary.partial} partial, ${summary.blocked} blocked.\n\n`;
  const triageItems = reportData.tests.filter((x) => ['failed', 'partial'].includes(x.status)).slice(0, 5);
  md += `### Top five items to investigate\n\n`;
  md += triageItems.length ? triageItems.map((x, i) => `${i + 1}. **${x.name}** (${x.status}) — ${x.details}`).join('\n') + '\n\n' : 'No executed failures or partial outcomes were recorded. Blocked tests still need to be run before declaring the application defect-free.\n\n';
  md += `## 6. Cleanup\n\n`;
  md += `- QA accounts authenticated or created: ${reportData.cleanup.qaAccountsCreated} of 5 were already marked as created in the private credentials file or were created during this run. Aliases: QA_USER_1 through QA_USER_5. No usernames or passwords are printed.\n`;
  md += `- QA rooms created during this run: ${createdRoomNames.length ? createdRoomNames.length : 0}; cleaned up: ${new Set(cleanedUpRoomNames).size}.\n`;
  md += `- Room cleanup: ${reportData.cleanup.roomCleanup}\n`;
  md += `- Test game sessions created: ${createdGameSessions.length}; closed through the owner UI: ${closedGameSessions.length}.\n`;
  md += `- Credentials: ${reportData.cleanup.credentialFile}\n`;
  md += `- Personal/existing accounts used: no. GitHub commits/deployments/production configuration changes: none.\n\n`;
  md += `## Environment and limitations\n\n`;
  md += `- Browser: ${metadata.browser || 'not started'}\n`;
  md += `- Source repository was readable for a read-only implementation review. The current source defines ` + '`#registerUsername`' + ` and ` + '`#registerPassword`' + ` fields and a minimum password length of 8. The form contains no email field or email verification step.\n`;
  md += `- ${metadata.notes.map(scrub).join('\n- ') || 'No additional environment notes.'}\n`;
  md += `- Browser logs are under ` + '`artifacts/browser-logs/`' + ` and screenshots under ` + '`artifacts/screenshots/`' + `. Credentials and auth state are excluded.\n`;
  await fs.writeFile(REPORT_FILE, md, { mode: 0o600 });
  try { await fs.chmod(REPORT_FILE, 0o600); } catch { /* Windows ACLs inherited from project folder. */ }

  console.log(`CACA QA run finished: ${summary.passed} passed, ${summary.failed} failed, ${summary.partial} partial, ${summary.blocked} blocked.`);
  console.log('Reports: CACA-QA-REPORT.md and results.json. Credentials remain in private/credentials.json and are not printed.');
}

run().catch(async (error) => {
  console.error(`QA runner stopped: ${scrub(error.stack || error.message)}`);
  try {
    await loadCredentials();
    blockPending(`Runner-level error: ${error.message}`);
    await finish({
      runId: RUN_ID,
      startedAt: new Date().toISOString(),
      website: BASE_URL,
      workerHealth: HEALTH_URL,
      sourceRepository: 'https://github.com/potatorman/caca',
      registrationModel: 'username + password only; no email or verification steps',
      browser: 'not available',
      notes: [error.message]
    });
  } catch {
    process.exitCode = 1;
  }
});
