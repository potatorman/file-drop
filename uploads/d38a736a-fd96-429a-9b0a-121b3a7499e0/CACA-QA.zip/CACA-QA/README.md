# CACA QA Tester — five-user end-to-end runner

This is a separate local Node.js + Playwright project for testing the deployed CACA website through its normal user interface. It does not modify the CACA source repository, Firebase rules/data directly, Cloudflare settings, production configuration, or GitHub.

## Important: preserve your existing QA credentials

You already created five QA accounts in the previous run. **Keep your current `private/credentials.json` file.** This updated ZIP intentionally does not contain that file.

The easiest update path is to extract this ZIP into your existing `CACA-QA` folder and allow the new project files to replace the old `qa.mjs`, `package.json`, `README.md`, and `scripts` files. The ZIP does not contain `private/credentials.json`, so it should remain in place.

If you extract to a new folder instead, copy this one file from your old QA folder into the new folder:

`private/credentials.json`

Do not paste or upload that file into chat. It contains your private QA usernames and passwords.

If there is no credentials file, the runner generates five new unique QA usernames and five cryptographically random passwords of 32 random bytes each (43-character Base64URL strings). Existing saved credentials are reused on future runs; accounts marked as created are logged in rather than registered again.

## CACA registration model

CACA registration is **username + password only**. The runner does not ask for email addresses, inboxes, verification codes, or email access. It uses the normal registration and login forms in CACA. The frontend enforces usernames of 3–20 valid characters and passwords of at least 8 characters; the QA passwords are at least 12 characters.

The duplicate-username test is guarded: it only attempts to register the username of a confirmed QA account and waits for the registration request to finish. It will not try to create a sixth account as a duplicate-test fallback.

## Setup on Windows PowerShell

Requires Node.js 20 or newer. PowerShell may block `npm.ps1` under your system execution policy. **Use the `.cmd` launchers below**; this avoids changing Windows security settings.

Run these commands from inside the `CACA-QA` folder:

```powershell
node --version
npm.cmd install
npx.cmd playwright install chromium
npm.cmd run check
npm.cmd run qa
```

To watch the browser instead of running headless:

```powershell
npm.cmd run qa:headed
```

The full run can take several minutes because it uses five isolated users and observes live multiplayer phases. Keep the terminal open until it prints the final pass/fail/partial/blocked totals.

Optional tuning:

```powershell
$env:CACA_QA_TIMEOUT_MS = "30000"
$env:CACA_QA_UNO_MAX_ACTIONS = "300"
npm.cmd run qa
```

`CACA_QA_UNO_MAX_ACTIONS` limits automated player actions in a single UNO game; the default is 240. It is a safety cap, not a claim that every match will finish within that many actions.

## What the runner covers

- Site and Cloudflare Worker `/health` preflight.
- Five independent user accounts; registration/login, duplicate usernames, too-short passwords, invalid login, simultaneous sessions, logout/login, refresh and browser-context reopen.
- Profile nickname and avatar changes (restored after the test).
- QA room creation, joining, member-list updates, second-room deletion through the normal owner UI, leave/rejoin, and non-member UI isolation.
- Five-user real-time chat, Turkish characters, emoji, 1,800-character messages, own-message edit/delete, and normal-member UI restrictions on other users' messages.
- Owner/admin/member UI permissions, admin promotion/revocation and a short-lived admin permission.
- Screen-shake and personal jumpscare image upload/delivery/expiration; invalid and oversized upload rejection.
- Shared UNO lobby creation, joining, host transfer, ready/unready, countdown cancellation attempt, refresh/reconnect and automated card play toward the results screen.
- Five-human Vampir Köylü role assignment, private role display, night action, discussion, voting and reconnect.
- Vampir Köylü bot-fill scenarios with target counts 5, 8 and 12, including participant-count and bot/real-user separation checks.
- Screenshots, browser console warnings/errors, page errors, failed requests and HTTP 5xx records.

Some inherently variable or expensive cases may still be marked `partial` or `blocked`: for example, both Vampir Köylü victory paths, every special UNO card branch, simultaneous race conditions, and long-running bot match completion are not automatically claimed as passed unless the UI evidence actually shows them.

## Safety boundaries

- Uses only the five accounts stored in `private/credentials.json` and rooms created with a `QA-` / `QA-DEL-` name by this run.
- Does not use your personal account.
- Does not use direct database writes or privileged Firebase/Cloudflare credentials for test decisions.
- Does not brute-force logins, run destructive load tests, modify unrelated users/rooms, change Firestore rules, change Worker settings, deploy, or push commits.
- It deletes only QA rooms created by the current run, and only through the normal room-owner UI. Previously created QA rooms from earlier runs are not auto-deleted; review those separately in CACA.
- QA accounts are retained. Account deletion is not attempted automatically.

## Private files and reports

- `private/credentials.json` — usernames/passwords; never share or commit.
- `private/auth-state/` — saved Playwright authentication state; never share or commit.
- `results.json` — machine-readable test outcomes; credentials are redacted.
- `CACA-QA-REPORT.md` — human-readable report.
- `artifacts/screenshots/` — redacted UI screenshots.
- `artifacts/browser-logs/` — redacted browser logs.

`private/`, `artifacts/`, and `node_modules/` are excluded by `.gitignore`. Do not commit or send the private folder.

## Test targets

- Website: `https://caca-dfe6c.web.app`
- Worker health: `https://caca-uno.patatesadam1589.workers.dev/health`
- Read-only source inspection: `https://github.com/potatorman/caca`

The runner interacts with the deployed website UI for pass/fail decisions. Source inspection only informs selectors and expected UI behavior.

## After the run

Send me these two files:

- `CACA-QA-REPORT.md`
- `results.json`

Do **not** send `private/credentials.json`, `private/auth-state/`, `.env` files, or any password/API-key/secret. The reports do not need those secrets.
