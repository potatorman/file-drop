import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';

function generateUsername(index, used = new Set()) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const candidate = `qa${randomBytes(5).toString('hex').slice(0, 8)}${index}`;
    if (/^[a-zA-Z0-9_]{3,20}$/.test(candidate) && !used.has(candidate.toLowerCase())) {
      used.add(candidate.toLowerCase());
      return candidate;
    }
  }
  throw new Error('Unable to generate a unique username.');
}

function generatePassword() {
  return randomBytes(24).toString('base64url');
}

const used = new Set();
const accounts = Array.from({ length: 5 }, (_, index) => ({
  username: generateUsername(index + 1, used),
  password: generatePassword()
}));

assert.equal(accounts.length, 5);
assert.equal(new Set(accounts.map((a) => a.username.toLowerCase())).size, 5);
for (const account of accounts) {
  assert.match(account.username, /^[a-zA-Z0-9_]{3,20}$/);
  assert.ok(account.password.length >= 12);
}
assert.equal('QA1!xyz'.length, 7, 'weak-password fixture must be shorter than 8');

console.log('Runner self-check passed: five unique username fixtures and five >=12-character secure password fixtures.');
console.log('Self-check does not contact CACA and is not counted as a CACA application test.');
